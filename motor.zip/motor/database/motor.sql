-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2024 at 08:56 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `motor`
--

-- --------------------------------------------------------

--
-- Table structure for table `bayar_cicilan`
--

CREATE TABLE `bayar_cicilan` (
  `no_bayar` int(20) NOT NULL,
  `tanggal_bayar` date NOT NULL,
  `kode_kredit_id` varchar(25) NOT NULL,
  `kode_pelanggan_id` text NOT NULL,
  `kode_motor` text NOT NULL,
  `jumlah_bayar_cicilan` int(225) NOT NULL,
  `anggsuran` int(50) NOT NULL,
  `keterangan_cicilan` text NOT NULL,
  `bulan_ini` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bayar_cicilan`
--

INSERT INTO `bayar_cicilan` (`no_bayar`, `tanggal_bayar`, `kode_kredit_id`, `kode_pelanggan_id`, `kode_motor`, `jumlah_bayar_cicilan`, `anggsuran`, `keterangan_cicilan`, `bulan_ini`) VALUES
(245, '2021-06-07', '78ui', '1', 'rt22', 2, 1, 'done', 1),
(246, '2021-07-07', '78ui', '1', 'rt22', 2, 2, 'done', 1),
(247, '2021-06-07', '78ui', '1', 'rt22', 2, 3, 'done', 1),
(248, '2021-06-07', '78ui', '1', 'rt22', 2, 4, 'done', 1),
(249, '2021-06-07', '78ui', '1', 'rt22', 2, 5, 'done', 1),
(250, '2021-06-07', '78ui', '1', 'rt22', 2, 6, 'done', 1),
(251, '2021-06-07', '78ui', '1', 'rt22', 2, 7, 'done', 1),
(252, '2021-06-07', '78ui', '1', 'rt22', 2, 8, 'done', 1),
(253, '2021-06-07', '78ui', '1', 'rt22', 2, 9, 'done', 1),
(254, '2021-06-07', '78ui', '1', 'rt22', 2, 10, 'done', 1),
(255, '2021-06-07', '78ui', '1', 'rt22', 2, 11, 'done', 1),
(256, '2021-06-07', '78ui', '1', 'rt22', 2, 12, 'done', 1);

-- --------------------------------------------------------

--
-- Table structure for table `beli_cash`
--

CREATE TABLE `beli_cash` (
  `kode_cash` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `pelanggan` varchar(20) NOT NULL,
  `kode_motor` varchar(20) NOT NULL,
  `harga` int(20) NOT NULL,
  `bayar` int(20) NOT NULL,
  `keterangan_cash` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beli_cash`
--

INSERT INTO `beli_cash` (`kode_cash`, `tanggal`, `pelanggan`, `kode_motor`, `harga`, `bayar`, `keterangan_cash`) VALUES
('CSH-01', '0000-00-00', '----- Pilih Nama Pel', '----- Pilih Motor --', 0, 0, ''),
('CSH-01', '2012-01-19', 'PEL-001', 'KZR-001', 0, 1000000, 'lunas'),
('CSH-01', '2012-01-19', 'PEL-001', 'KZR-001', 0, 1000000, 'lunas'),
('CSH-012', '2012-01-25', 'PEL-001', 'KZR-003', 0, 1000000, 'belum lunas'),
('4353', '2021-06-16', '3423', 'KMR-001', 0, 2147483647, 'done');

-- --------------------------------------------------------

--
-- Table structure for table `beli_kredit`
--

CREATE TABLE `beli_kredit` (
  `kode_kredit` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `kode_pelanggan_kredit` text NOT NULL,
  `kode_motor` text NOT NULL,
  `uang_muka` int(20) NOT NULL,
  `lama_cicilan` int(20) NOT NULL,
  `sisa_cicilan` int(11) NOT NULL,
  `Keterangan_kredit` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beli_kredit`
--

INSERT INTO `beli_kredit` (`kode_kredit`, `tanggal`, `kode_pelanggan_kredit`, `kode_motor`, `uang_muka`, `lama_cicilan`, `sisa_cicilan`, `Keterangan_kredit`) VALUES
('78ui', '2021-06-07', '1', 'rt22', 5000000, 12, 0, 'Terima'),
('K06', '2024-01-24', '3', 'RT31', 2000000, 12, 12, 'Terima');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_motor`
--

CREATE TABLE `jenis_motor` (
  `kd_jenismotor` int(11) NOT NULL,
  `kd_merk` int(11) NOT NULL,
  `jenis_motor` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `merk_motor`
--

CREATE TABLE `merk_motor` (
  `kd_merek` int(11) NOT NULL,
  `nama_merek` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `motor`
--

CREATE TABLE `motor` (
  `kode_motor` varchar(255) NOT NULL,
  `merek` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `warna` varchar(20) NOT NULL,
  `harga` int(225) NOT NULL,
  `dp` float NOT NULL,
  `angsuran` float NOT NULL,
  `photo` varchar(225) NOT NULL,
  `per_bulan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `motor`
--

INSERT INTO `motor` (`kode_motor`, `merek`, `type`, `warna`, `harga`, `dp`, `angsuran`, `photo`, `per_bulan`) VALUES
('rt22', 'crf', 'matic', 'hitam', 10000000, 2000000, 444444, 'images.jpeg', 12),
('RT25', 'crf', 'tril', 'merah', 30000000, 4000000, 29666700, 'Honda-CRF150L.jpg', 12),
('RT26', 'crf', 'tril', 'pink', 10000000, 3000000, 583333, 'pink.jpg', 12),
('RT27', 'vespa', 'metik', 'pink', 10000000, 2000000, 333333, 'pinkvespain.jpg', 12),
('RT28', 'honda scopy', 'scopy', 'hitam', 9000000, 4000000, 416667, 'png-transparent-honda-scoopy-motorcycle-car-south-jakarta-honda-scooter-car-color3.png', 12),
('RT29', 'honda scopy', 'scopy', 'kuning', 10000000, 4000000, 500000, 'download_(1).jpeg', 12),
('RT30', 'Honda', 'scopy', 'biru', 10000000, 2000000, 833333, 'download (1).jpeg', 12),
('RT31', 'vespa', 'matic', 'biru', 10000000, 2000000, 833333, 'images (1).jpeg', 12),
('RT32', 'crf', 'matic', 'hitam', 9000000, 1800000, 750000, 'download (2).jpeg', 12),
('RT33', 'suzuki', 'matic', 'putih', 20000000, 4000000, 1333330, 'download_(3).jpeg', 12),
('RT34', 'suzuki', 'gsx', 'biru', 35000000, 7000000, 1555560, 'gsx1.jpeg', 18),
('RT35', 'yamaha', 'matic', 'hitam', 33000000, 6600000, 2200000, 'nmax1.png', 12);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `kode_pelanggan` varchar(20) NOT NULL,
  `nama_lengkap` varchar(25) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` int(11) NOT NULL,
  `ktp` varchar(225) NOT NULL,
  `npwp` varchar(255) NOT NULL,
  `slip_gaji` varchar(255) NOT NULL,
  `keterangan` text NOT NULL,
  `tmp_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `kk` varchar(255) NOT NULL,
  `foto` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`kode_pelanggan`, `nama_lengkap`, `alamat`, `no_hp`, `ktp`, `npwp`, `slip_gaji`, `keterangan`, `tmp_lahir`, `tgl_lahir`, `kk`, `foto`) VALUES
('1', 'zahra artamevia', 'kajen kabupaten pekalongan jawa tengah', 2147483647, 'document-8_9085621.png', 'document-8_9085621.png', 'document-8_9085621.png', 'Kawin', 'pekalongan', '2021-06-17', 'document-8_9085621.png', 'cewe1.jpeg'),
('3', 'jojo', 'bekasi', 894284932, 'document-8_9085615.png', 'document-8_9085615.png', 'document-8_9085615.png', 'Kawin', 'jakarta', '2024-01-19', 'document-8_9085615.png', 'jojo.jpeg'),
('4', 'natan', 'bekasi', 894284932, 'document-8_9085622.png', 'document-8_9085622.png', 'document-8_9085622.png', 'Kawin', 'laketoba', '2024-01-19', 'document-8_9085622.png', 'download.jpeg'),
('5', 'suryo', 'bekasi', 894284932, 'document-8_90856213.png', 'document-8_90856213.png', 'document-8_90856213.png', 'Kawin', 'jakarta', '2024-01-19', 'document-8_90856213.png', 'suryo.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_motor`
--

CREATE TABLE `pembelian_motor` (
  `kd_pembelian` int(11) NOT NULL,
  `kd_jenismotor` int(11) NOT NULL,
  `nama_pembeli` varchar(25) NOT NULL,
  `nopol` varchar(20) NOT NULL,
  `stnk` text NOT NULL,
  `bpkp` text NOT NULL,
  `tgl_pembelian` date NOT NULL,
  `harga_pembelian` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_user257`
--

CREATE TABLE `tb_user257` (
  `id_user257` int(50) NOT NULL,
  `nama` varchar(80) NOT NULL,
  `email` varchar(40) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(225) NOT NULL,
  `akses_level` varchar(15) NOT NULL,
  `is_active` int(2) NOT NULL,
  `ket` text NOT NULL,
  `photo` varchar(225) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user257`
--

INSERT INTO `tb_user257` (`id_user257`, `nama`, `email`, `username`, `password`, `akses_level`, `is_active`, `ket`, `photo`, `tanggal`) VALUES
(19, 'alghi', 'alghi@gmail.com', 'alghi123', 'alghi123', 'admin', 0, 'admin', '31357151.png', '2024-01-17 03:28:15'),
(20, 'jabbar', 'jabbar@gmail.com', 'jabbar', 'jabbar', 'user', 0, 'admin', '31357152.png', '2024-01-22 09:11:41'),
(21, 'intan', 'intan@gmail.com', 'intan', 'intan1', 'admin', 0, 'test', 'cewe.png', '2024-01-23 15:59:27'),
(22, 'icha', 'icha@gmail.com', 'ichaa', 'icha123', 'admin', 0, 'admin', 'cewe1.png', '2024-01-24 05:49:35'),
(23, 'indah', 'indah@gmail.com', 'indahh', 'indah123', 'user', 0, 'test', 'cewe2.png', '2024-01-24 05:50:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bayar_cicilan`
--
ALTER TABLE `bayar_cicilan`
  ADD PRIMARY KEY (`no_bayar`),
  ADD KEY `kode_kredit` (`kode_kredit_id`),
  ADD KEY `kode_pelanggan_id` (`kode_pelanggan_id`(3072)),
  ADD KEY `kode_motor` (`kode_motor`(3072));

--
-- Indexes for table `beli_cash`
--
ALTER TABLE `beli_cash`
  ADD KEY `kode_motor` (`kode_motor`),
  ADD KEY `kode_motor_2` (`kode_motor`);

--
-- Indexes for table `beli_kredit`
--
ALTER TABLE `beli_kredit`
  ADD PRIMARY KEY (`kode_kredit`),
  ADD KEY `kode_motor` (`kode_motor`(3072));

--
-- Indexes for table `jenis_motor`
--
ALTER TABLE `jenis_motor`
  ADD PRIMARY KEY (`kd_jenismotor`),
  ADD KEY `kd_merk` (`kd_merk`);

--
-- Indexes for table `merk_motor`
--
ALTER TABLE `merk_motor`
  ADD PRIMARY KEY (`kd_merek`);

--
-- Indexes for table `motor`
--
ALTER TABLE `motor`
  ADD PRIMARY KEY (`kode_motor`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`kode_pelanggan`),
  ADD KEY `nama_lengkap` (`nama_lengkap`);

--
-- Indexes for table `pembelian_motor`
--
ALTER TABLE `pembelian_motor`
  ADD PRIMARY KEY (`kd_pembelian`),
  ADD KEY `nama_pembeli` (`nama_pembeli`),
  ADD KEY `kd_jenismotor` (`kd_jenismotor`);

--
-- Indexes for table `tb_user257`
--
ALTER TABLE `tb_user257`
  ADD PRIMARY KEY (`id_user257`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bayar_cicilan`
--
ALTER TABLE `bayar_cicilan`
  MODIFY `no_bayar` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- AUTO_INCREMENT for table `jenis_motor`
--
ALTER TABLE `jenis_motor`
  MODIFY `kd_jenismotor` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `merk_motor`
--
ALTER TABLE `merk_motor`
  MODIFY `kd_merek` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembelian_motor`
--
ALTER TABLE `pembelian_motor`
  MODIFY `kd_pembelian` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_user257`
--
ALTER TABLE `tb_user257`
  MODIFY `id_user257` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bayar_cicilan`
--
ALTER TABLE `bayar_cicilan`
  ADD CONSTRAINT `bayar_cicilan_ibfk_1` FOREIGN KEY (`kode_kredit_id`) REFERENCES `beli_kredit` (`kode_kredit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jenis_motor`
--
ALTER TABLE `jenis_motor`
  ADD CONSTRAINT `jenis_motor_ibfk_1` FOREIGN KEY (`kd_merk`) REFERENCES `merk_motor` (`kd_merek`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `merk_motor`
--
ALTER TABLE `merk_motor`
  ADD CONSTRAINT `merk_motor_ibfk_1` FOREIGN KEY (`kd_merek`) REFERENCES `jenis_motor` (`kd_jenismotor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pembelian_motor`
--
ALTER TABLE `pembelian_motor`
  ADD CONSTRAINT `pembelian_motor_ibfk_1` FOREIGN KEY (`nama_pembeli`) REFERENCES `pelanggan` (`kode_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
