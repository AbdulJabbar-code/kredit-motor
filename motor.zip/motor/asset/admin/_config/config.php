<?php 
date_default_timezone_get('Asia/Jakarta');
session_start();
$con = mysqli_connect('localhost','root','','pustaka257');
if (mysqli_connect_errno()) {
	echo mysqli_connect_error();
	# code...
}
function base_url($url=null){
	$base_url = "http://localhost/pustaka257";
	if ($url !=null)  {
		return $base_url. "/" .$url;

		# code...
	}else{
		return $base_url;
	}
}

 ?>