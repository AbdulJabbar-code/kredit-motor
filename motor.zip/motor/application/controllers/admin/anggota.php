<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggota extends CI_Controller {



	public function __construct()
	{
		parent::__construct();
		$this->load->model('anggota_model');
	}


	public function index()
	{
			$anggota = $this->anggota_model->listing();

		$data = array('title' => 'Data Anggota('.count($anggota).' Data)',
						'anggota'=>  $anggota,
						'isi' => 'admin/anggota/list');
		$this->load->view('dasbor/layout/wrapper', $data, FALSE);
	}


	public function tambah()
	{

			$valid = $this->form_validation;
			$valid->set_rules('nama','Nama','required',array(
				'required'    => 'nama harus diisi'));
			$valid->set_rules('email','Email','required|valid_email',array(
				'required'    => 'email harus diisi',
				'vallid_email'=> 'format email tidak benar'));
			$valid->set_rules('username','Username','required|is_unique[anggota257.username257]',array(
				'required'    =>'username harus diiisi','is_unique' => 'Username <strong>'.$this->input->post('username').'&nbsp;sudah ada. Buat username baru'));
		
			
			
			if ($valid->run()) {

				if(!empty($_FILES['gambar']['name'])){
					$config['upload_path'] = './asset/anggota/';
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size'] = '999999999';
					$config['max_width'] = '1024';
					$config['max_height'] = '768';
					$this->load->library('upload',$config);

					if( ! $this->upload->do_upload('gambar')){
							# code...
					$data = array('title' => 'Tambah Data anggota',
						'error' =>$this->upload->display_errors('Ukuran file terlalu besar atau format file salah /'),
						'isi' => 'admin/anggota/tambah');
					$this->load->view('dasbor/layout/wrapper', $data, FALSE);

			}else{
				$upload_data				= array('uploads' =>$this->upload->data());

				$config['image_library']	= 'gd2';
				$config['source_image']		= './asset/anggota/'.$upload_data['uploads']['file_name'];
				$config['quality']			= "100%";
				$config['maintain_ratio']	=TRUE;
				$config['width']			= 360;
				$config['height']			= 360;
				$config['x_axis']			= 0;
				$config['y_axis']			= 0;
				$config['thumb_marker']		= '';
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
				$data = array('title' => 'Tambah Data Anggota',
						'isi' => 'admin/anggota/tambah');
					$this->load->view('dasbor/layout/wrapper', $data, FALSE);

				$i = $this->input;
				$data = array(
								'id_user257'					=> $this->session->userdata('id_user257'),
							  'namaanggota257'        => $i->post('nama'),
							  'email257'       => $i->post('email'),
							  'username257'    => $i->post('username'),
							  'password257'    => md5($i->post('password')),
							  'statusanggota257' => $i->post('status'),
							  'telepon257' => $i->post('telepon'),
							   'kelas257' => $i->post('kelas'),
							  'photo257'      	  => $upload_data['uploads']['file_name']
							);
				$this->anggota_model->tambah($data);
				$this->session->set_flashdata('sukses','data telah ditambah');
				redirect(base_url('admin/anggota'),'refresh');
			}
}
	
	}
	$data = array('title' => 'Tambah Data Anggota',
						'isi' => 'admin/anggota/tambah');
					$this->load->view('dasbor/layout/wrapper', $data, FALSE);

	}

			public function edit($id_anggota)
	{
		$anggota = $this->anggota_model->detail($id_anggota);


			$valid = $this->form_validation;
			$valid->set_rules('nama','Nama','required',array(
				'required'    => 'nama harus diisi'));
	
			
				if ($valid->run()) {

				if(!empty($_FILES['gambar']['name'])){
					$config['upload_path'] = './asset/anggota/';
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size'] = '1000000';
					$config['max_width'] = '1024';
					$config['max_height'] = '768';
					$this->load->library('upload',$config);

					if( ! $this->upload->do_upload('gambar')){
							# code...
					$data = array('title' => 'Edit Data anggota',
						'anggota'=>$anggota,
						'error' =>$this->upload->display_errors('Ukuran file terlalu besar atau format file salah /'),
						'isi' => 'admin/anggota/edit');
					$this->load->view('admin/layout/wrapper', $data, FALSE);

			}else{
				$upload_data				= array('uploads' =>$this->upload->data());

				$config['image_library']	= 'gd2';
				$config['source_image']		= './asset/anggota/'.$upload_data['uploads']['file_name'];
				$config['quality']			= "100%";
				$config['maintain_ratio']	=TRUE;
				$config['width']			= 360;
				$config['height']			= 360;
				$config['x_axis']			= 0;
				$config['y_axis']			= 0;
				$config['thumb_marker']		= '';
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
	$i = $this->input;
				$data = array('idanggota257'=> $id_anggota,
					'iduser265'					=> $this->session->userdata('id_user'),
							  'namaanggota257'        => $i->post('nama'),
							  'email257'       => $i->post('email'),
							  'username257'    => $i->post('username'),
							  'password257'    => md5($i->post('password')),
							  'statusanggota257' => $i->post('status'),
							  'telepon257' => $i->post('telepon'),
							   'kelas257' => $i->post('kelas'),
							  'photo257'      	  => $upload_data['uploads']['file_name']
							);
				$this->anggota_model->edit($data);
				$this->session->set_flashdata('sukses','data telah edit');
				redirect(base_url('admin/anggota'),'refresh');
			}
}else{
$i = $this->input;
					$data = array('idanggota257'=> $id_anggota,
							  'namaanggota257'        => $i->post('nama'),
							  'email257'       => $i->post('email'),
							  'username257'    => $i->post('username'),
							  'password257'    => md5($i->post('password')),
							  'statusanggota257' => $i->post('status'),
							  'telepon257' => $i->post('telepon'),
							   'kelas257' => $i->post('kelas')
							  
							);
				$this->anggota_model->edit($data);
				$this->session->set_flashdata('sukses','data telah edit');
				redirect(base_url('admin/anggota'),'refresh');


}
}
	$data = array('title' => 'edit Data Anggota',
						'anggota'=> $aggota,
						'isi' => 'admin/anggota/edit');
					$this->load->view('admin/layout/wrapper', $data, FALSE);
					}
public function delete($id_anggota ){
			//Proteksi Hapus disini
		// if($this->session->userdata('username') == "" && $this->session->userdata('akses_level') == ""){
		// 	$this->session->set_flashdata('sukses','Silahkan Login Dulu');
		// 	redirect(base_url('login'),'refresh');
		// 	}
			//Proses Hapus Gambar
			$anggota = $this->anggota_model->detail($id_anggota);
			unlink('./asset/anggota/'.$anggota->photo257);
			//End Proteksi
			$data = array('id_anggota257'	=> $id_anggota);
			$this->anggota_model->delete($data);
			$this->session->set_flashdata('sukses','Data Telah DiHapus');
			redirect(base_url('admin/anggota'),'refresh');
			}

				public function detail($id_anggota){
	//Proteksi Hapus Disini
	if($this->session->userdata('username') == "" && $this->session->userdata('akses_level') == ""){
		$this->session->set_flashdata('sukses','Silahkan Login Dulu');
		redirect(base_url('login'),'refresh');
	}
	//Proses Hapus Gambar
	$anggota = $this->anggota_model->detail($id_anggota);

	//End Proteksi
	$data = array('idanggota257'	=> $id_anggota);
	
	redirect(base_url('admin/anggota'),'refresh');
}

public function pdf(){
$this->load->library('dompdf_gen');
		// $this->load->library('mypdf');
		// $this->mypdf->generate('admin/user/pdf');
	
	$data['user'] = $this->user_model->tampil('tb_user257')->result();
 	$this->load->view('admin/user/pdf', $data,FALSE);
 	$paper_size = 'A4';
 	$orientation = 'landscape';
	$html = $this->output->get_output();

 	$this->dompdf->set_paper($paper_size,$orientation);

	$this->dompdf->load_html($html);
	
	$this->dompdf->render();
 	$this->dompdf->stream("laporan.pdf",array('Attachment'=>0));
	
 
}

}

/* End of file anggota.php */
/* Location: ./application/controllers/admin/anggota.php */