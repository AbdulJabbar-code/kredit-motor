<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dasbor extends CI_Controller {

	public function index()
	{
		$data['tb_user257'] = $this->db->get_where('tb_user257', ['username'=>
$this->session->userdata('username')])->row_array();

		$data = array('title' => 'Halaman Dasbor',
						'isi' => 'admin/dasbor/list');
		$this->load->view('admin/layout/wrapper', $data );





	}

}

/* End of file Dasbor.php */
/* Location: ./application/controllers/Admin/Dasbor.php */