<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merek extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('merek_model');
		
	}

	public function index()
	{
			$merek = $this->merek_model->listing();

		$data = array('title' => 'Data merek('.count($merek).' Data)',
						'merek'=>  $merek,
						'isi' => 'admin/merek/list');
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

}

/* End of file merek.php */
/* Location: ./application/controllers/admin/merek.php */