<?php
defined('BASEPATH') or exit('No direct script access allowed');

class cicilan extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('cicilan_model');
		$this->load->model('pelanggan_model');
		$this->load->model('motor_model');
		$this->load->model('kredit_model');
	}

	public function index($kode_pelanggan)
	{
		date_default_timezone_set('Asia/Jakarta');
		$cicilan = $this->cicilan_model->listing();
		$kode = rawurldecode($this->uri->segment('5'));
		$kode_kredit = rawurldecode($this->uri->segment('7'));
		$pelanggan_cicilan = $this->db->query("SELECT * FROM bayar_cicilan INNER JOIN beli_kredit ON bayar_cicilan.kode_kredit_id = beli_kredit.kode_kredit
		INNER JOIN motor ON bayar_cicilan.kode_motor = motor.kode_motor
		INNER JOIN pelanggan ON bayar_cicilan.kode_pelanggan_id = pelanggan.kode_pelanggan
		WHERE kode_pelanggan_id = '$kode' AND kode_kredit_id = '$kode_kredit'")->num_rows();
		// $pelanggan_aktif = $this->cicilan_model->cicilan_join($kode);
		$pelanggan_aktif = $this->db->query("SELECT * FROM bayar_cicilan INNER JOIN beli_kredit ON bayar_cicilan.kode_kredit_id = beli_kredit.kode_kredit
		INNER JOIN motor ON bayar_cicilan.kode_motor = motor.kode_motor
		INNER JOIN pelanggan ON bayar_cicilan.kode_pelanggan_id = pelanggan.kode_pelanggan
		WHERE kode_pelanggan_id = '$kode' AND kode_kredit_id = '$kode_kredit' ORDER BY no_bayar DESC")->result();
		$data = array(
			'title' => 'Data cicilan(' . count($cicilan) . ' Data)',
			'cicilan' =>  $pelanggan_aktif,
			'kode'	=> $kode,
			'kode_kredit'	=>	$kode_kredit,
			'pelanggan_cicilan'	=>	$pelanggan_cicilan,
			'isi' => 'admin/cicilan/list'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	public function pelanggan_motor()
	{
		date_default_timezone_set('Asia/Jakarta');
		$cicilan = $this->cicilan_model->listing();
		$pelanggan = $this->pelanggan_model->listing();
		$kredit = $this->kredit_model->listing();

		$data = array(
			'title' => 'Pelanggan Motor(' . count($cicilan) . ' Data)',
			'cicilan' =>  $cicilan,
			'pelanggan'	=>	$kredit,
			'isi' => 'admin/cicilan/pelanggan_motor'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	public function tambah()
	{
		$pelanggan 	= $this->pelanggan_model->listing();
		$motor = $this->motor_model->listing();
		$kode = rawurldecode($this->uri->segment('4'));
		$kode_kredit = rawurldecode($this->uri->segment('6'));
		$kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode'")->result_array();
		$bayar_cicilan = $this->db->query("SELECT * FROM bayar_cicilan WHERE kode_pelanggan_id = '$kode'")->result_array();
		$kredit_kode = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit != '$kode' AND kode_kredit = '$kode_kredit'")->result();
		$kode_kredit = $this->kredit_model->kode_kredit($kode);
		$pengguna = $this->pelanggan_model->listing();
		$nama_lengkap = $this->db->query("SELECT * FROM pelanggan WHERE kode_pelanggan = '$kode'")->row_array();

		$kode_nama = "";
		$nama = "";

		if(!$kode_nama) {
			$kode_nama = $nama_lengkap['nama_lengkap'];
		} elseif(!$nama) {
			$nama = $nama_lengkap['nama_lengkap'];
		}

		$valid = $this->form_validation;

		$valid->set_rules('kode_kredit','Kode kredit','required');
		$valid->set_rules('user','user','required');

		if ($valid->run() === false) {
			$data = [
				'title' 		=> 'Tambah Data cicilan',
				'pelanggan'			=>	$pelanggan,
				'motor' 		=> $motor,
				'kode'	=>	$kode,
				'data_identitas'	=>	$nama_lengkap,
				'kode_nama'	=>	$kode_nama,
				'nama'	=>	$nama,
				'kredit_kode'	=>	$kredit_kode,
				'kredit' 		=> $kredit,
				'isi'			=> 'admin/cicilan/tambah'
			];
			$this->load->view('admin/layout/wrapper', $data, false);
		} else {
			date_default_timezone_set('Asia/Jakarta');
			$kredit = $this->kredit_model->listing();
			$i = $this->input;
			// $lama = $kredit->lama_cicilan;
			// $jlh = $lama - 1;
			$data = array(
				'tanggal_bayar'			=> $i->post('tabay'),
				'kode_kredit_id'   		=> $i->post('kode_kredit'),
				'kode_pelanggan_id'		=> $i->post('nama_user'),
				'kode_motor' 			=> $i->post('motor'),
				'jumlah_bayar_cicilan'  => $i->post('anggsuran'),
				'anggsuran'    			=> $i->post('angsuran_ke'),
				'keterangan_cicilan'	=> 'Belum Melakukan Pembayaran',
				'bulan_ini'				=>	0
			);

			$this->db->insert('bayar_cicilan',$data);
			$this->session->set_flashdata('massage', '<div class="alert alert-success" role="alert"><i class="fa fa-check">Data Berhasil Ditambahkan.</i></div>');
			redirect(base_url('admin/cicilan/index/kode_pelanggan/' . $kode), 'refresh');
		}
	}

	public function add()
	{
		$pelanggan 	= $this->pelanggan_model->listing();
		$motor = $this->motor_model->listing();
		$kode = rawurldecode($this->uri->segment('5'));
		$code_kredit = rawurldecode($this->uri->segment('7'));
		$kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode'")->result_array();
		$kredit_kode = $this->db->query("SELECT * FROM beli_kredit INNER JOIN motor ON beli_kredit.kode_motor = motor.kode_motor WHERE kode_pelanggan_kredit = '$kode'")->result();
		$nama_lengkap = $this->db->query("SELECT * FROM pelanggan WHERE kode_pelanggan = '$kode'")->row_array();

		$kode_nama = "";
		$nama = "";

		if($kode_nama == null) {
			$kode_nama = $nama_lengkap['nama_lengkap'];
		} else {
			$kode_nama = "";
		}

		if($nama == null) {
			$nama = $nama_lengkap['nama_lengkap'];
		} else {
			$nama = "";
		}

		$pengguna = $this->pelanggan_model->listing();

		$valid = $this->form_validation;

		$valid->set_rules('kode_kredit','Kode kredit','required');
		$valid->set_rules('user','user','required');

		if ($valid->run() === false) {
			$data = [
				'title' 		=> 'Tambah Data cicilan',
				'pelanggan'			=>	$pelanggan,
				'motor' 		=> $motor,
				'kode'	=>	$kode,
				'data_identitas'	=>	$nama_lengkap,
				'kode_nama'	=>	$kode_nama,
				'nama'	=>	$nama,
				'code_kredit'	=>	$code_kredit,
				'kredit_kode'	=>	$kredit_kode,
				'kredit' 		=> $kredit,
				'isi'			=> 'admin/cicilan/add'
			];
			$this->load->view('admin/layout/wrapper', $data, false);
		} else {
			date_default_timezone_set('Asia/Jakarta');
			$kredit = $this->kredit_model->listing();
			$i = $this->input;
			// $lama = $kredit->lama_cicilan;
			// $jlh = $lama - 1;
			$input_kode = $i->post('kode_kredit');;
			$data_pelanggan = $this->db->query("SELECT * FROM beli_kredit INNER JOIN motor ON beli_kredit.kode_motor = motor.kode_motor  WHERE kode_kredit = '$input_kode'")->row_array();
			
			$data = array(
				'tanggal_bayar' 		=> $i->post('tabay'),
				'kode_kredit_id'   	=> $i->post('kode_kredit'),
				'kode_pelanggan_id' => $data_pelanggan['kode_pelanggan_kredit'],
				'kode_motor' => $data_pelanggan['kode_motor'],
				'jumlah_bayar_cicilan'    => $data_pelanggan['angsuran'],
				'anggsuran'    => 1,
				'keterangan_cicilan'	=>	'Belum Melakukan Pembayaran',
				'bulan_ini'	=>	0
			);
			$this->db->insert('bayar_cicilan',$data);
			$this->session->set_flashdata('massage', '<div class="alert alert-success" role="alert"><i class="fa fa-check">Data Berhasil Ditambahkan.</i></div>');
			redirect(base_url('admin/cicilan/index/kode_pelanggan/' . $kode . '/kode_kredit/' . $code_kredit), 'refresh');
		}
	}

	public function edit($no_bayar,$nama_lengkap)
	{
		$cicilan = $this->cicilan_model->detaill($no_bayar);
		$kredit = $this->cicilan_model->listing();
		$valid = $this->form_validation;
		$no_bayar = rawurldecode($this->uri->segment('4'));
		$kode_kridit = rawurldecode($this->uri->segment('10'));
		$nama_lengkap_pelanggan = rawurldecode($this->uri->segment('6'));
		$kode_pelanggan = rawurldecode($this->uri->segment('8'));
		$valid->set_rules('kode_kredit','Kode Kredit','required');

		if ($valid->run() === false) {
			$data = [
				'title' 		=> 'Edit Data cicilan',
				'cicil'		=> $cicilan,
				'nama_lengkap_pelanggan'	=>	$nama_lengkap_pelanggan,
				'kredit'	=> $kredit,
				'kode_pelanggan'	=>	$kode_pelanggan,
				'kode_kredit'	=>	$kode_kridit,
				'isi'			=> 'admin/cicilan/edit'
			];
			$this->load->view('admin/layout/wrapper', $data, false);
		} else {
			$i = $this->input;
			$tgl = $i->post('tabay');
			$angsuran = $i->post('cicil');
			$cicil = $i->post('kecil');

			$data = [
				'no_bayar'	=>	$no_bayar,
				'tanggal_bayar'	=>	$tgl,
				'anggsuran'	=>	$angsuran,
				'keterangan_cicilan'	=>	$cicil
			];

			$this->cicilan_model->edit($data);
			$this->session->set_flashdata('massage', '<div class="alert alert-success" role="alert"><i class="fa fa-check">Data Berhasil Diedit.</i></div>');
			redirect(base_url('admin/cicilan/index/kode_pelanggan/' . $kode_pelanggan . '/kode_kredit/' . $kode_kridit), 'refresh');
		}
	}

	public function add_cicilan($no_bayar,$kode_kredit,$kode_pelanggan)
	{
		$cicilan = $this->cicilan_model->detaill($no_bayar);
		$kode_kredit_pelanggan	= $this->uri->segment('6');
		$kode_pelanggan_kredit	= $this->uri->segment('8');
		$first_rows = $this->db->query("SELECT * FROM bayar_cicilan WHERE kode_kredit_id = '$kode_kredit_pelanggan' AND kode_pelanggan_id = '$kode_pelanggan_kredit'")->row_array();

		$num_rows = $this->db->query("SELECT * FROM bayar_cicilan WHERE kode_kredit_id = '$kode_kredit_pelanggan' AND kode_pelanggan_id = '$kode_pelanggan_kredit'")->num_rows();
		
		$cicilan_12_bulan = 12;
		$cicilan_18_bulan = 18;
		$cicilan_24_bulan = 24;
		$cicilan_30_bulan = 30;
		$cicilan_36_bulan = 36;

		$bayar_cicilan_12_bulan = "2.288.000";
		$bayar_cicilan_18_bulan = "1.690.000";
		$bayar_cicilan_24_bulan = "1.398.000";
		$bayar_cicilan_30_bulan = "1.230.000";
		$bayar_cicilan_36_bulan = "1.125.000";

		if($first_rows['jumlah_bayar_cicilan'] == $bayar_cicilan_12_bulan) {
			if($num_rows != $cicilan_12_bulan) {
				$data = [
					'no_bayar' 			=> $no_bayar + 1,
					'tanggal_bayar' 		=> date("Y-m-d"),
					'kode_kredit_id' => 	$cicilan->kode_kredit_id,
					'kode_pelanggan_id' => 	$cicilan->kode_pelanggan_id,
					'kode_motor' => 	$cicilan->kode_motor,
					'jumlah_bayar_cicilan' => $cicilan->jumlah_bayar_cicilan,
					'anggsuran'	=>	$cicilan->anggsuran + 1,
					'keterangan_cicilan'    => "Belum Melakukan Pembayaran",
					'bulan_ini'	=>	0
				];
				$this->cicilan_model->tambah($data);
				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');

				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");
			} else {
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");

				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');
			}
		}
		 elseif($first_rows['jumlah_bayar_cicilan'] == $bayar_cicilan_18_bulan) {
			if($num_rows != $cicilan_18_bulan) {
				$data = [
					'no_bayar' 			=> $no_bayar + 1,
					'tanggal_bayar' 		=> date("Y-m-d"),
					'kode_kredit_id' => 	$cicilan->kode_kredit_id,
					'kode_pelanggan_id' => 	$cicilan->kode_pelanggan_id,
					'kode_motor' => 	$cicilan->kode_motor,
					'jumlah_bayar_cicilan' => $cicilan->jumlah_bayar_cicilan,
					'anggsuran'	=>	$cicilan->anggsuran + 1,
					'keterangan_cicilan'    => "Belum Melakukan Pembayaran",
					'bulan_ini'	=>	0
				];
				$this->cicilan_model->tambah($data);
		
				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');
				
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");
			} else {
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");

				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');
			}
		} elseif($first_rows['jumlah_bayar_cicilan'] == $bayar_cicilan_24_bulan) {
			if($num_rows != $cicilan_24_bulan) {
				$data = [
					'no_bayar' 			=> $no_bayar + 1,
					'tanggal_bayar' 		=> date("Y-m-d"),
					'kode_kredit_id' => 	$cicilan->kode_kredit_id,
					'kode_pelanggan_id' => 	$cicilan->kode_pelanggan_id,
					'kode_motor' => 	$cicilan->kode_motor,
					'jumlah_bayar_cicilan' => $cicilan->jumlah_bayar_cicilan,
					'anggsuran'	=>	$cicilan->anggsuran + 1,
					'keterangan_cicilan'    => "Belum Melakukan Pembayaran",
					'bulan_ini'	=>	0
				];
				$this->cicilan_model->tambah($data);
		
				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');
				
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit'  AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");
			} else {
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");

				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');
			}
		} elseif($first_rows['jumlah_bayar_cicilan'] == $bayar_cicilan_30_bulan) {
			if($num_rows != $cicilan_30_bulan) {
				$data = [
					'no_bayar' 			=> $no_bayar + 1,
					'tanggal_bayar' 		=> date("Y-m-d"),
					'kode_kredit_id' => 	$cicilan->kode_kredit_id,
					'kode_pelanggan_id' => 	$cicilan->kode_pelanggan_id,
					'kode_motor' => 	$cicilan->kode_motor,
					'jumlah_bayar_cicilan' => $cicilan->jumlah_bayar_cicilan,
					'anggsuran'	=>	$cicilan->anggsuran + 1,
					'keterangan_cicilan'    => "Belum Melakukan Pembayaran",
					'bulan_ini'	=>	0
				];
				$this->cicilan_model->tambah($data);
		
				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');

				
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");
			} else {
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");

				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');
			}
		} elseif($first_rows['jumlah_bayar_cicilan'] == $bayar_cicilan_36_bulan) {
			if($num_rows != $cicilan_36_bulan) {
				$data = [
					'no_bayar' 			=> $no_bayar + 1,
					'tanggal_bayar' 		=> date("Y-m-d"),
					'kode_kredit_id' => 	$cicilan->kode_kredit_id,
					'kode_pelanggan_id' => 	$cicilan->kode_pelanggan_id,
					'kode_motor' => 	$cicilan->kode_motor,
					'jumlah_bayar_cicilan' => $cicilan->jumlah_bayar_cicilan,
					'anggsuran'	=>	$cicilan->anggsuran + 1,
					'keterangan_cicilan'    => "Belum Melakukan Pembayaran",
					'bulan_ini'	=>	0
				];
				$this->cicilan_model->tambah($data);
		
				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');

				
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");
			} else {
				$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'")->row_array();
				$sisa = $query_kredit['sisa_cicilan'];

				$this->db->query("UPDATE beli_kredit SET sisa_cicilan = $sisa - 1 WHERE kode_pelanggan_kredit = '$kode_pelanggan_kredit' AND kode_kredit = '$kode_kredit_pelanggan'");

				$this->db->set('keterangan_cicilan', 'done');
				$this->db->set('bulan_ini', 1);
				$this->db->where('no_bayar',$no_bayar);
				$this->db->update('bayar_cicilan');
			}
		}

		$this->session->set_flashdata('massage', '<div class="alert alert-success" role="alert"><i class="fa fa-check">Data Berhasil Diedit.</i></div>');
		redirect(base_url('admin/cicilan/index/kode_pelanggan/' . $kode_pelanggan_kredit . '/kode_kredit/' . $kode_kredit_pelanggan), 'refresh');
	}

	public function pdf()
	{
		$this->load->library('dompdf_gen');
		// $this->load->library('mypdf');
		// $this->mypdf->generate('admin/user/pdf');

		$data['cicilan'] = $this->cicilan_model->listing();
		$this->load->view('admin/cicilan/pdf', $data, FALSE);
		$paper_size = 'A4';
		$orientation = 'landscape';
		$html = $this->output->get_output();

		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);

		$this->dompdf->render();
		$this->dompdf->stream("laporan.pdf", array('Attachment' => 0));
	}
}

/* End of file cicilan.php */
/* Location: ./application/controllers/admin/cicilan.php */
