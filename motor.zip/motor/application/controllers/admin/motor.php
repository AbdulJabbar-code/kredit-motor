<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Motor extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('motor_model');
	}

	public function index()
	{
		$motor = $this->motor_model->listing();

		$data = array(
			'title' => 'Data motor(' . count($motor) . ' Data)',
			'motor' =>  $motor,
			'isi' => 'admin/motor/list'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}
	public function tambah()
	{


		$valid = $this->form_validation;
		$valid->set_rules('kode_motor', 'Kode', 'required', array(
			'required'    => 'kode harus diisi'
		));



		if ($valid->run()) {

			if (!empty($_FILES['gambar']['name'])) {
				$config['upload_path'] = './asset/img/motor/';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$config['max_size'] = '300';
				$config['max_width'] = '1024';
				$config['max_height'] = '768';
				$this->load->library('upload', $config);

				if (!$this->upload->do_upload('gambar')) {
					# code...
					
					$kode_motor = $this->generate_next_code();
					$data = array(
						'title' => 'Tambah Data motor',
						'error' => $this->upload->display_errors('FORMAT GAMBAR HARUS JPEG/PNG/JPG/GIF & UKURAN MAX GAMBAR 1024 X 768'),
						'kode_motor' =>  $kode_motor,
						'isi' => 'admin/motor/tambah'
					);
					$this->load->view('admin/layout/wrapper', $data, FALSE);
				} else {
					$upload_data				= array('uploads' => $this->upload->data());

					$config['image_library']	= 'gd2';
					$config['source_image']		= './asset/img/motor/' . $upload_data['uploads']['file_name'];
					$config['quality']			= "100%";
					$config['maintain_ratio']	= TRUE;
					$config['width']			= 360;
					$config['height']			= 360;
					$config['x_axis']			= 0;
					$config['y_axis']			= 0;
					$config['thumb_marker']		= '';
					$this->load->library('image_lib', $config);
					$this->image_lib->resize();
					$i = $this->input;
					$kode_motor_pelanggan = $i->post('kode_motor');

					$query_motor = $this->db->query("SELECT * FROM motor WHERE kode_motor = '$kode_motor_pelanggan'")->num_rows();
					if($query_motor) {
						echo "<script>
							alert('Kode Motor Sudah Ada');
							</script>";
							redirect(base_url('admin/motor/tambah'), 'refresh');
					}

					$data = array(
						'kode_motor' => $i->post('kode_motor'),
						'merek'       => $i->post('merekm'),
						'type'    => $i->post('typem'),
						'harga'    => $i->post('hargam'),
						'warna' => $i->post('warnam'),
						'dp' => set_value('dpm'),
						'angsuran' => set_value('angsuran'),

						'photo'      	  => $upload_data['uploads']['file_name'],
						'per_bulan'	=>	$i->post('per_bulan'),
					);
					$data['dp'] = $data['harga'] * 0.20;
					$data['angsuran'] = ($data['harga'] - $data['dp']) / $data['per_bulan'];
				

					$this->motor_model->tambah($data);
					$this->session->set_flashdata('sukses', 'data telah ditambah');
					redirect(base_url('admin/motor'), 'refresh');
				}

				
			}
		}

		$kode_motor = $this->generate_next_code();

		$data = array(
			'title' => 'Tambah Data motor',
			'kode_motor' =>  $kode_motor,
			'isi' => 'admin/motor/tambah',
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	public function edit($kode_motor)
	{

		$motor = $this->motor_model->detail($kode_motor);


		if (!empty($_FILES['gambar']['name'])) {
			$config['upload_path'] = './asset/img/motor/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size'] = '300';
			$config['max_width'] = '1024';
			$config['max_height'] = '768';
			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('gambar')) {
				# code...
				$data = array(
					'title' => 'Edit Data motor',
					'motor' => $motor,
					'error' => $this->upload->display_errors('Ukuran file terlalu besar atau format file salah /'),
					'isi' => 'admin/motor/edit'
				);
				$this->load->view('admin/layout/wrapper', $data, FALSE);
			} else {
				$upload_data				= array('uploads' => $this->upload->data());

				$config['image_library']	= 'gd2';
				$config['source_image']		= './asset/img/motor/' . $upload_data['uploads']['file_name'];
				$config['quality']			= "100%";
				$config['maintain_ratio']	= TRUE;
				$config['width']			= 360;
				$config['height']			= 360;
				$config['x_axis']			= 0;
				$config['y_axis']			= 0;
				$config['thumb_marker']		= '';
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
				$i = $this->input;
			
				$data = array(
					'kode_motor' => $i->post('kode_motor'),
					'merek'       => $i->post('merekm'),
					'type'    => $i->post('typem'),
					'harga'    => $i->post('hargam'),
					'warna' => $i->post('warnam'),
					'dp' => set_value('dp'),
					'angsuran' => set_value('angsuranm'),
					'photo'      	  => $upload_data['uploads']['file_name'],
					'per_bulan'	=>	$i->post('per_bulan')
				);
				$data['dp'] = $data['harga'] * 0.20;
					$data['angsuran'] = ($data['harga'] - $data['dp']) / $data['per_bulan'];

				$this->motor_model->edit($data);
				$this->session->set_flashdata('sukses', 'data telah edit');
				redirect(base_url('admin/motor'), 'refresh');
			}
		} else {
			$i = $this->input;
			
			$data = array(
				'kode_motor' => $i->post('kode_motor'),
				'merek'       => $i->post('merekm'),
				'type'    => $i->post('typem'),
				'harga'    => $i->post('hargam'),
				'warna' => $i->post('warnam'),
				'dp' => set_value('dp'),
				'angsuran' => set_value('angsuranm'),
				'photo'      	  => $upload_data['uploads']['file_name'],
				'per_bulan'	=>	$i->post('per_bulan')
			);
			$data['dp'] = $data['harga'] * 0.20;
				$data['angsuran'] = ($data['harga'] - $data['dp']) / $data['per_bulan'];

			$this->motor_model->edit($data);
			$this->session->set_flashdata('sukses', 'data telah edit');
			redirect(base_url('admin/motor'), 'refresh');
		}

		$data = array(
			'title' => 'edit Data motor',
			'motor' => $motor,
			'isi' => 'admin/motor/edit'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	


	public function delete($id)
	{
		$where = array('kode_motor' => $id);

		$this->motor_model->delete($where);

				$this->session->set_flashdata('sukses', 'Data Telah DiHapus');
				redirect(base_url('admin/motor'), 'refresh');
	}

	public function listmotor()
	{

		$cek = $this->db->count_all("motor");

		$data['motor'] = $this->db->get("motor")->result();
		$data['title'] = 'Daftar motor';
		$data['isi'] = 'admin/motor/listmotor';
		$this->load->view('admin/layout/wrapper', $data);
		// $this->load->view('motor/listmotor', $data);

	}

	public function pdf()
	{
		$this->load->library('dompdf_gen');
		// $this->load->library('mypdf');
		// $this->mypdf->generate('admin/user/pdf');

		$data['motor'] = $this->motor_model->listing();
		$this->load->view('admin/motor/pdf', $data, FALSE);
		$paper_size = 'A4';
		$orientation = 'landscape';
		$html = $this->output->get_output();

		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);

		$this->dompdf->render();
		$this->dompdf->stream("laporan.pdf", array('Attachment' => 0));
	}

	// function untuk generate auto code number
    public function generate_next_code() {
        $latest_code    = $this->motor_model->get_last_id();
        // mengambil kode yang terakhir kali di input
        $last_number    = (int) substr($latest_code, -2);
        // auto generic next number pada autocode
        $next_number    = $last_number + 1;
        // auto generic code dengan format MK - + 3 angka dari $next_number
        $next_code      = 'RT' . str_pad($next_number, 2 , '0', STR_PAD_LEFT);
        return $next_code;
    }

}

/* End of file motor.php */
/* Location: ./application/controllers/admin/motor.php */
