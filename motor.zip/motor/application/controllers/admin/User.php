<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
 

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
	}

	
	public function index()
	{
		$user = $this->user_model->listing();

		$data = array('title' => 'Data user('.count($user).' Data)',
						'user'=>  $user,
						'isi' => 'admin/user/list');
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	public function tambah()
	{

			$valid = $this->form_validation;
			$valid->set_rules('nama','Nama','required',array(
				'required'    => 'nama harus diisi'));
			$valid->set_rules('email','Email','required|valid_email',array(
				'required'    => 'email harus diisi',
				'vallid_email'=> 'format email tidak benar'));
			$valid->set_rules('username','Username','required|is_unique[tb_user257.username]',array(
				'required'    =>'username harus diiisi','is_unique' => 'Username <strong>'.$this->input->post('username').'&nbsp;sudah ada. Buat username baru'));
			$valid->set_rules('password','Password','required|min_length[6]',array(
				'required'    => 'password harus diisi',
				'min_length'  => 'Password minimal 6 karakter'));
			
			
			if ($valid->run()) {

				if(!empty($_FILES['gambar']['name'])){
					$config['upload_path'] = './asset/user/';
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size'] = '300';
					$config['max_width'] = '1024';
					$config['max_height'] = '768';
					$this->load->library('upload',$config);

					if( ! $this->upload->do_upload('gambar')){
							# code...
					$data = array('title' => 'Tambah Data User',
						'error' =>$this->upload->display_errors('Ukuran file terlalu besar atau format file salah /'),
						'isi' => 'admin/user/tambah');
					$this->load->view('admin/layout/wrapper', $data, FALSE);

			}else{
				$upload_data				= array('uploads' =>$this->upload->data());

				$config['image_library']	= 'gd2';
				$config['source_image']		= './asset/user/'.$upload_data['uploads']['file_name'];
				$config['quality']			= "100%";
				$config['maintain_ratio']	=TRUE;
				$config['width']			= 360;
				$config['height']			= 360;
				$config['x_axis']			= 0;
				$config['y_axis']			= 0;
				$config['thumb_marker']		= '';
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
				$i = $this->input;
				$data = array(
							  'nama'        => $i->post('nama'),
							  'email'       => $i->post('email'),
							  'username'    => $i->post('username'),
							  'password'    => md5($i->post('password')),
							  'akses_level' => $i->post('akses_level'),
							  'ket'  => $i->post('keterangan'),
							  'photo'      	  => $upload_data['uploads']['file_name']
							);
				$this->user_model->tambah($data);
				$this->session->set_flashdata('sukses','data telah ditambah');
				redirect(base_url('admin/user'),'refresh');
			}
}
	
	}
	$data = array('title' => 'Tambah Data User',
						'isi' => 'admin/user/tambah');
					$this->load->view('admin/layout/wrapper', $data, FALSE);

	}
 
		public function edit($id_user)
	{
		$user = $this->user_model->detail($id_user);


			$valid = $this->form_validation;
			$valid->set_rules('nama','Nama','required',array(
				'required'    => 'nama harus diisi'));
	
			
				if ($valid->run()) {

				if(!empty($_FILES['gambar']['name'])){
					$config['upload_path'] = './asset/user/';
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size'] = '1000000';
					$config['max_width'] = '1024';
					$config['max_height'] = '768';
					$this->load->library('upload',$config);

					if( ! $this->upload->do_upload('gambar')){
							# code...
					$data = array('title' => 'Edit Data User',
						'user'=>$user,
						'error' =>$this->upload->display_errors('Ukuran file terlalu besar atau format file salah /'),
						'isi' => 'admin/user/edit');
					$this->load->view('admin/layout/wrapper', $data, FALSE);

			}else{
				$upload_data				= array('uploads' =>$this->upload->data());

				$config['image_library']	= 'gd2';
				$config['source_image']		= './asset/user/'.$upload_data['uploads']['file_name'];
				$config['quality']			= "100%";
				$config['maintain_ratio']	=TRUE;
				$config['width']			= 360;
				$config['height']			= 360;
				$config['x_axis']			= 0;
				$config['y_axis']			= 0;
				$config['thumb_marker']		= '';
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();

				$i = $this->input;
				$data = array('id_user257'		  => $id_user,
							  'nama'        => $i->post('nama'),
							  'email'       => $i->post('email'),
							  'username'    => $i->post('username'),
							  'password'    => md5($i->post('password')),
							  'akses_level' => $i->post('akses_level'),
							  'ket'  => $i->post('keterangan'),
					 		  'photo'      	  => $upload_data['uploads']['file_name']
							);
				$this->user_model->edit($data);
				$this->session->set_flashdata('sukses','data telah di Edit');
				redirect(base_url('admin/user'),'refresh');
			}
}else{
$i = $this->input;
				$data = array('id_user257'		  => $id_user,
							  'nama'        => $i->post('nama'),
							  'email'       => $i->post('email'),
							  'username'    => $i->post('username'),
							  'password'    => md5($i->post('password')),
							  'akses_level' => $i->post('akses_level'),
							  'ket'  => $i->post('keterangan'),
					 		  'photo'      	  => $upload_data['uploads']['file_name']
							);
				$this->user_model->edit($data);
				$this->session->set_flashdata('sukses','data telah di Edit');
				redirect(base_url('admin/user'),'refresh');


}
}
	$data = array('title' => 'edit Data user',
						'user'=> $user,
						'isi' => 'admin/user/edit');
					$this->load->view('admin/layout/wrapper', $data, FALSE);
					}
public function delete($id_user ){
			//Proteksi Hapus disini
		// if($this->session->userdata('username') == "" && $this->session->userdata('akses_level') == ""){
		// 	$this->session->set_flashdata('sukses','Silahkan Login Dulu');
		// 	redirect(base_url('login'),'refresh');
		// 	}
			//Proses Hapus Gambar
			$user = $this->user_model->detail($id_user);
			unlink('./asset/user/'.$user->photo257);
			//End Proteksi
			$data = array('id_user257'	=> $id_user);
			$this->user_model->delete($data);
			$this->session->set_flashdata('sukses','Data Telah DiHapus');
			redirect(base_url('admin/user'),'refresh');
			}

				public function detail($id_user){
	//Proteksi Hapus Disini
	if($this->session->userdata('username') == "" && $this->session->userdata('akses_level') == ""){
		$this->session->set_flashdata('sukses','Silahkan Login Dulu');
		redirect(base_url('login'),'refresh');
	}
	//Proses Hapus Gambar
	$user = $this->user_model->detail($id_user257);

	//End Proteksi
	$data = array('id_user257'	=> $id_user257);
	
	redirect(base_url('admin/user'),'refresh');
}

public function pdf(){
$this->load->library('dompdf_gen');
		// $this->load->library('mypdf');
		// $this->mypdf->generate('admin/user/pdf');
	
	$data['user'] = $this->user_model->tampil('tb_user257')->result();
 	$this->load->view('admin/user/pdf', $data,FALSE);
 	$paper_size = 'A4';
 	$orientation = 'landscape';
	$html = $this->output->get_output();

 	$this->dompdf->set_paper($paper_size,$orientation);

	$this->dompdf->load_html($html);
	
	$this->dompdf->render();
 	$this->dompdf->stream("laporan.pdf",array('Attachment'=>0));
	
 
	
}


} 