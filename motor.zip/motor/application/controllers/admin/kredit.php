<?php
defined('BASEPATH') or exit('No direct script access allowed');

class kredit extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('kredit_model');
		$this->load->model('pelanggan_model');
		$this->load->model('motor_model');
		$this->load->model('cicilan_model');
	}

	public function index()
	{
		$kredit = $this->kredit_model->listing();
		$data = array(
			'title' => 'Data kredit(' . count($kredit) . ' Data)',
			'kredit' =>  $kredit,
			'isi' => 'admin/kredit/list'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}
	public function tambah()
	{
		$pelanggan 	= $this->pelanggan_model->listing();
		$motor = $this->motor_model->listing();

		$valid = $this->form_validation;

		$valid->set_rules('namak', 'namak', 'required', array(
			'required' => '%s Harus Diisi'
		));
		if ($valid->run() === false) {

			$data = [
				'title' 		=> 'Tambah Data kredit',
				'pelanggan'			=>	$pelanggan,
				'motor' 		=> $motor,
				'isi'			=> 'admin/kredit/tambah'
			];
			$this->load->view('admin/layout/wrapper', $data, false);
		} else {
			$i = $this->input;
			$kode = $i->post('merekk');
			$nama = $i->post('namak');
			$code_kredit = $i->post('kode_kredit');
			$query = $this->db->query("SELECT * FROM motor WHERE kode_motor = '$kode'")->row_array();
			$query_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_motor = '$kode' AND kode_pelanggan_kredit = '$nama'")->num_rows();
			if($query_kredit) {
				echo "<script>
					alert('Pelanggan Sudah Pernah Membeli Motor');
					</script>";
			redirect(base_url('admin/kredit/tambah'), 'refresh');
			}

			$query_kode_kredit = $this->db->query("SELECT * FROM beli_kredit WHERE kode_kredit = '$code_kredit'")->num_rows();
			if($query_kode_kredit) {
				echo "<script>
					alert('Kode Kredit Sudah Ada');
					</script>";
					redirect(base_url('admin/kredit/tambah'), 'refresh');
			}

			$data = array(
				'kode_kredit'	=>	$i->post('kode_kredit'),
				'kode_pelanggan_kredit' 		=> $i->post('namak'),
				'kode_motor'			=> $i->post('merekk'),
				'tanggal'   	=> $i->post('tanggalk'),
				'uang_muka'    => set_value('uangk'),
				'lama_cicilan'    => $query['per_bulan'],
				'sisa_cicilan'    => $query['per_bulan'],
				'Keterangan_kredit'     => $i->post('keterangank')
			);
			$harga=$query['harga'];
			$data['uang_muka'] =$harga * 0.20;

			$this->kredit_model->tambah($data);
			$this->session->set_flashdata('massage', '<div class="alert alert-success" role="alert"><i class="fa fa-check">Data Berhasil Ditambahkan.</i></div>');
			redirect(base_url('admin/kredit'), 'refresh');
		}
	}

	public function kirim($kode_kredit)
	{
		$kredit 	= $this->kredit_model->detaill($kode_kredit);
		$lama = $kredit->sisa_cicilan;
		$jlh = $lama - 1;
		$data1 = [
			'kode_kredit'	=> $kode_kredit,
			'sisa_cicilan'				=> $jlh,
		];
		$this->kredit_model->edit($data1);
		$data = array(
			'kode_kredit' 		=> $kode_kredit,
			'kode_pelanggan_kredit'			=> $kredit->kode_pelanggan_kredit,
			'kode_motor' 		=> $kredit->kode_motor
		);
		$this->cicilan_model->tambah($data);
		$this->session->set_flashdata('massage', '<div class="alert alert-success" role="alert"><i class="fa fa-check">Data Berhasil Ditambahkan.</i></div>');
		redirect(base_url('admin/cicilan'), 'refresh');
	}



	public function pdf(){
$this->load->library('dompdf_gen');
		// $this->load->library('mypdf');
		// $this->mypdf->generate('admin/user/pdf');
	
	$data['kredit'] = $this->kredit_model->listing();
 	$this->load->view('admin/kredit/pdf', $data,FALSE);
 	$paper_size = 'A4';
 	$orientation = 'landscape';
	$html = $this->output->get_output();

 	$this->dompdf->set_paper($paper_size,$orientation);

	$this->dompdf->load_html($html);
	
	$this->dompdf->render();
 	$this->dompdf->stream("laporan.pdf",array('Attachment'=>0));
	
 
}
}

/* End of file kredit.php */
/* Location: ./application/controllers/admin/kredit.php */
