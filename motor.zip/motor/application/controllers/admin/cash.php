<?php
defined('BASEPATH') or exit('No direct script access allowed');

class cash extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('cash_model');
		$this->load->model('pelanggan_model');
		$this->load->model('motor_model');
	}

	public function index()
	{
		$cash = $this->cash_model->listing();

		$data = array(
			'title' => 'Data cash(' . count($cash) . ' Data)',
			'cash' =>  $cash,
			'isi' => 'admin/cash/list'
		);
		$this->load->view('dasbor/layout/wrapper', $data, FALSE);
	}
	public function tambah()
	{
		$pelanggan 	= $this->pelanggan_model->listing();
		$motor = $this->motor_model->listing();

		$valid = $this->form_validation;

		$valid->set_rules('kodec', 'kode cash', 'required', array(
			'required' => '%s Harus Diisi'
		));



		if ($valid->run() === false) {

			$data = [
				'title' 		=> 'Tambah Data CASH',
				'pelanggan'			=>	$pelanggan,
				'motor' 		=> $motor,
				'isi'			=> 'admin/cash/tambah'
			];
			$this->load->view('admin/layout/wrapper', $data, false);
		} else {
			$i = $this->input;
			$data = array(
				'kode_cash' 			=> $i->post('kodec'),
				'pelanggan' 		=> $i->post('namac'),
				'kode_motor'			=> $i->post('merekc'),
				'tanggal'   	=> $i->post('tanggalc'),
				'harga'    => $i->post('hargac'),
				'bayar'     	=> $i->post('bayarc'),
				'keterangan_cash'     => $i->post('keteranganc')
			);

			$this->cash_model->tambah($data);
			$this->session->set_flashdata('massage', '<div class="alert alert-success" role="alert"><i class="fa fa-check">Data Berhasil Ditambahkan.</i></div>');
			redirect(base_url('admin/cash'), 'refresh');
		}
	}
}

/* End of file cash.php */
/* Location: ./application/controllers/admin/cash.php */
