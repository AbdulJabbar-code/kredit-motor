<?php
defined('BASEPATH') or exit('No direct script access allowed');

class pelanggan extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('pelanggan_model');
	}

	public function index()
	{
		$pelanggan = $this->pelanggan_model->listing();

		$data = array(
			'title' => 'Data pelanggan(' . count($pelanggan) . ' Data)',
			'pelanggan' =>  $pelanggan,
			'isi' => 'admin/pelanggan/list'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}
	public function tambah()
{
   $valid = $this->form_validation;
   $valid->set_rules('kode_pelanggan', 'Kode', 'required', array(
      'required'    => 'kode harus diisi'
   ));

   if ($valid->run()) {
      $i = $this->input;

      $config['upload_path'] = './asset/img/pelanggan/';
      $config['allowed_types'] = 'gif|jpg|png';

      $this->load->library('upload', $config);

      if ($this->upload->do_upload('gambar')) {
         $upload_data = $this->upload->data();

         // Your existing code for image library and resizing

         $data = array(
            'kode_pelanggan'  => $i->post('kode_pelanggan'),
            'nama_lengkap'    => $i->post('nama_lengkap'),
            'alamat'          => $i->post('alamat'),
            'no_hp'           => $i->post('no_hp'),
            'tgl_lahir'       => $i->post('tgl_lahir'),
            'tmp_lahir'       => $i->post('tmp_lahir'),
            'kk'              => $upload_data['file_name'],
            'foto'            => $upload_data['file_name'],
            'ktp'             => $upload_data['file_name'],
            'npwp'            => $upload_data['file_name'],
            'slip_gaji'       => $upload_data['file_name'],
            'keterangan'      => $i->post('keterangan')
         );

         $this->pelanggan_model->tambah($data);
         $this->session->set_flashdata('sukses', 'data telah ditambah');
         redirect(base_url('admin/pelanggan'), 'refresh');
      } else {
         $data = array(
            'title' => 'Tambah Data pelanggan',
            'error' => $this->upload->display_errors('Ukuran file terlalu besar atau format file salah /'),
            'isi' => 'admin/pelanggan/tambah'
         );
         $this->load->view('admin/layout/wrapper', $data, FALSE);
      }
   }

   $data = array(
      'title' => 'Tambah Data pelanggan',
      'isi' => 'admin/pelanggan/tambah'
   );
   $this->load->view('admin/layout/wrapper', $data, FALSE);
}

public function edit($kode_pelanggan)
{
    $pelanggan = $this->pelanggan_model->detail($kode_pelanggan);

    if ($this->input->post()) {
        $valid->run($this->input->post());

        $i = $this->input;

        // ... Pengaturan upload file ...

        if ($this->upload->do_upload('gambar')) {
            $upload_data = $this->upload->data();

            // ... Pengolahan gambar ...

            $data = array(
                'kode_pelanggan'   => $kode_pelanggan,
                'nama_lengkap'     => $i->post('nama_lengkap'),
                'alamat'           => $i->post('alamat'),
                // ... Informasi file lainnya ...
                'keterangan'       => $i->post('keterangan')
            );

            $this->pelanggan_model->edit($data);
            $this->session->set_flashdata('sukses', 'Data telah diedit');
            redirect(base_url('admin/pelanggan'), 'refresh');
        } else {
            $data = array(
                'title' => 'Edit Data pelanggan',
                'pelanggan' => $pelanggan,
                'error' => $this->upload->display_errors('Ukuran file terlalu besar atau format file salah /'),
                'isi' => 'admin/pelanggan/edit'
            );
            $this->load->view('admin/layout/wrapper', $data, FALSE);
        }
    }

    $data = array(
        'title' => 'Edit Data pelanggan',
        'pelanggan' => $pelanggan,
        'isi' => 'admin/pelanggan/edit'
    );
    $this->load->view('admin/layout/wrapper', $data, FALSE);
}

	// public function delete($kode_pelanggan)
	// {
	// 	//Proses Hapus Gambar
	// 	$pelanggan = $this->pelanggan_model->detail($kode_pelanggan);
	// 	unlink('./asset/img/pelanggan/' . $pelanggan->photo);
	// 	//End Proteksi
	// 	$data = array('kode_pelanggan'	=> $kode_pelanggan);
	// 	$this->pelanggan_model->delete($data);
	// 	$this->session->set_flashdata('sukses', 'Data Telah DiHapus');
	// 	redirect(base_url('admin/pelanggan'), 'refresh');
	// }

   public function delete($id)
	{
		$where = array('kode_pelanggan' => $id);

		$this->pelanggan_model->delete($where);

				$this->session->set_flashdata('sukses', 'Data Telah DiHapus');
				redirect(base_url('admin/pelanggan'), 'refresh');
	}


	public function detail($kode_pelanggan)
	{
		//Proteksi Hapus Disini
		if ($this->session->userdata('username') == "" && $this->session->userdata('akses_level') == "") {
			$this->session->set_flashdata('sukses', 'Silahkan Login Dulu');
			redirect(base_url('login'), 'refresh');
		}
		//Proses Hapus Gambar
		$pelanggan = $this->pelanggan_model->detail($kode_pelanggan);

		//End Proteksi
		$data = array('kode_pelanggan'	=> $kode_pelanggan);

		redirect(base_url('admin/pelanggan'), 'refresh');
	}

	public function pdf()
	{
		$this->load->library('dompdf_gen');
		// $this->load->library('mypdf');
		// $this->mypdf->generate('admin/user/pdf');

		$data['pelanggan'] = $this->pelanggan_model->listing();
		$this->load->view('admin/pelanggan/pdf', $data, FALSE);
		$paper_size = 'A4';
		$orientation = 'landscape';
		$html = $this->output->get_output();

		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);

		$this->dompdf->render();
		$this->dompdf->stream("laporan.pdf", array('Attachment' => 0));
	}
}

/* End of file pelanggan.php */
/* Location: ./application/controllers/admin/pelanggan.php */
