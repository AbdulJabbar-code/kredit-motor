<?php
class Login extends CI_Controller {
    public function __construct() { 
        parent::__construct();
        //menarik file login model di folder Models
        $this->load->model('Login_model');
        // menarik libtrary Session di codeigneter
        $this->load->library('session');
    }
    public function index() {
        $this->load->view('login_view');
    }
    public function proses_login() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
    
        $user = $this->Login_model->cek_login($username,$password);
    
        if ($user) {
            //jika login berhasil, simpan informasi user (nama lengkap dan setatus) ke dalam session
            $data_session = array(
                'nama'=> $user->nama,
                'akses_level'=> $user->akses_level,
                'email'=> $user->email
            );
            $this->session->set_userdata($data_session);

            //tampilkan pesan selamat datang menggunakan alert javascript
            echo '<script>alert("Selamat Datang ' .$user->nama .' sebagai '. $user->akses_level. '");</script>';
            
        //Redirect ke halaman 'wellcome' setelah alert
        echo '<script>window.location.href="' . site_url('admin/dasbor') . '";</script>';
        }else{
            //jika login gagal, tampilkan pesan kesalahan
            echo '<script>alert("Login Gagal!! mungkin salah password");</script>';
            //redirect ke halaman login setelah gagal login
            echo '<script>window.location.href="' . site_url('Login') .'";</script>';
        }
    }
    public function logout() {
        $this->session->sess_destroy(); // hapus semua session
        redirect('Login');
    }
    
    public function forgot()
{
    $this->load->view('forgot');
}

public function process_forgot()
{
    $email = $this->input->post('email');

    // Check if the email exists in your database
    $user = $this->Login_model->get_user_by_email($email);

    if ($user) {
        // If the email is found, display the user's password using an alert
        echo '<script>alert("Your password is: ' . $user->password . '");</script>';
        // You should consider enhancing security and not displaying the plain password in a production application.

        // Redirect to the login page
        echo '<script>window.location.href="' . site_url('Login') . '";</script>';
    } else {
        // If the email is not found, show an "Email Not Found" alert
        echo '<script>alert("Email Not Found");</script>';

        // Redirect back to the forgot password page
        echo '<script>window.location.href="' . site_url('Login/forgot') . '";</script>';
    }
}

}
