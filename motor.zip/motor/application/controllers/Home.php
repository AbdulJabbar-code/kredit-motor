<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()	{
		parent::__construct();
		$this->load->model('model_home');
	}
	
	public function index() {
		$data=array('title'		=>'Tutorial Code Igniter - Java Web Media',
					'buku'	=> $this->model_home->beranda(),
					'isi'  		=>'home/index_home'
						);
		$this->load->view('home/layout/wrapper',$data);	
	}
	
	// Read buku
	// public function read($read) {
	// 	// $data['buku'] = $this->model_home->beranda();
	// 	// $data['detail']	= $this->model_home->beranda($read);
	// 	$data=array('title'		=>$data['detail']['judul'],
	// 				'buku'	=> $this->model_home->beranda(),
	// 				'detail' 	=> $this->model_home->beranda($read),
	// 				'isi'  		=>'home/read_view'
	// 					);
	// 	$this->load->view('home/layout/wrapper', $data, FALSE);
	// }

	


}