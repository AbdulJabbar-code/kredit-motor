<?php

require_once 'head.php';
require_once 'navbar.php';
require_once 'sidebar.php';
require_once 'content.php';
require_once 'footer.php';
require_once 'wrapper.php';
?>