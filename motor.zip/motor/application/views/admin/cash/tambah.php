              
                    <?php 
                  echo validation_errors('<div class="alert alert-danger"><i class="fa fa-warning"></i>','</div>');
                  if (isset($error)) {
                    # code...
                    echo '<div class ="alert alert-warning">';
                    echo $error;
                    echo '</div>';
                  }
                  echo form_open_multipart(base_url('admin/cash/tambah/'));

                   ?>
      
                    <div class="row">
                    <div class="col-md-6">
                       <div class="form-group ">
                    <label >Kode Cash</label>

                    <input type="text" class="form-control" id="kodec" name="kodec" value="<?= set_value('kode_cash'); ?>" placeholder="Kode Cash">
                  </div>
                  <div class="form-group">
                       <label >Nama Pelanggan</label>
                    
                       <select class="form-control select2bs4" name="namac" id="namac" style="width: 100%;" required>
                    <option selected="selected">----- Pilih Nama Pelanggan -----</option>
                    <?php 
                      foreach ($pelanggan as $pel) {
                     ?>
                     <option value="<?= $pel->kode_pelanggan ?>">
                      <?= $pel->kode_pelanggan ?> - <?= $pel->nama_lengkap ?>
                     </option>
                     <?php 
                     }
                      ?>
                </select>
                    </div>
                    <div class="form-group">
                      <label > Merk Motor</label>
                       <select class="form-control select2bs4" name="merekc" id="merekc" style="width: 100%;" required>
                    <option selected="selected">----- Pilih Motor -----</option>
                    <?php 
                      foreach ($motor as $mot) {
                     ?>
                     <option value="<?= $mot->kode_motor ?>">
                      <?= $mot->kode_motor ?> - <?= $mot->merek ?>
                     </option>
                     <?php 
                     }
                      ?>
                </select>
                     </div>
                     <div class="form-group ">
                       <label> Harga</label>
                    
                      <select class="form-control select2bs4" name="hargac" id="hargac" style="width: 100%;" required>
                    <option selected="selected">----- Pilih Harga Motor -----</option>
                    <?php 
                      foreach ($motor as $mot) {
                     ?>
                     <option value="<?= $mot->kode_motor ?>">
                      <?= $mot->kode_motor ?> - <?= $mot->harga ?>
                     </option>
                     <?php 
                     }
                      ?>
                </select>
                          </div>
                            <div class="form-group ">
                       <label> Bayar</label>
                    
                      <input type="text" class="form-control" id="pass" name="bayarc"  value="<?= set_value('tanggal_masuk'); ?>" placeholder="Harga">
                          </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group ">
                    <label >Tanggal</label>
                    
                    
                     <input type="date" class="form-control" name="tanggalc" id="tanggalc" placeholder="Tanggal Masuk Buku" value="<?= set_value('tanggal'); ?>" >
                    </div>

                        <div class="form-group ">
                    <label >Keterangan</label>
                    
                      <input type="text" class="form-control" id="pass" name="keteranganc"  value="" placeholder="Keterangan">
                    
                     
                  
                       <div class="form-group ">
                        
                      </div>
                       <button type="submit" name="simpan" class="btn btn-primary btn-xs">Simpan Data</button>
                        <button type="reset" name="reset" class="btn btn-secondary btn-xs">Batal</button>
                    </div>
                  </div>
                </div>
                  <?php 
                  echo form_close();
                   ?>


                 

                   

               



                 