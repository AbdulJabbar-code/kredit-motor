<h2><center>Data Kredit Motor</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		 <th>#</th>
            <th>Kode Kredit</th>
            <th>Nama Pelanggan</th>
            <th>Merk Motor</th>
            <th>Harga</th>
            <th>Uang Muka (Dp)</th>
            <th>Angsuran</th>
            <th>Lama Cicilan</th>
            <th>Sisa Cicilan</th>
            <th>Tanggal</th>
            <th>Konfirmasi</th>
	</tr>
	<?php 
	$no = 1;
	foreach($kredit as $kredit)
	{
		?>
		<tr>
			<td><?= $no ?></td>
            <td><?= $kredit->kode_kredit ?></td>
              <td><?= $kredit->kode_pelanggan ?></td>
              <td><?= $kredit->kode_motor  ?>-<?= $kredit->merek ?> </td>
              <td><?= $kredit->harga  ?></td>
              <td><?= $kredit->uang_muka  ?></td>
              <td><?= $kredit->angsuran ?></td>
              <td><?= $kredit->lama_cicilan ?> Bulan</td>
              <td><?= $kredit->sisa_cicilan ?> Bulan</td>
              <td><?= $kredit->tanggal  ?></td>
              <td><?= $kredit->Keterangan_kredit  ?></td>
              
		</tr>
		<?php
	}
	?>
</table>