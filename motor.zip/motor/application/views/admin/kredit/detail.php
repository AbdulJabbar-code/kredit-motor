 <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#detail<?=$kredit->kode_kredit  ?>">
                  <i class="fa fa-eye">Detail</i>
                </button>
      <div class="modal fade" id="detail<?=$kredit->kode_kredit  ?>">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header badge-primary">
              <h4 class="modal-title">Detail Data user : <?= $kredit->kode_kredit?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button> 
            </div>
            <div class="modal-body">
              <table class="table table-bordered table-striped">
               
                   <tr>
                  <th>Nama</th>
                  <td><?= $kredit->kode_kredit ?></td>
                </tr>
                <tr>
                  <th>Email - Telepon</th>
                  <td><?= $kredit->kode_pelanggan_kredit ?> - <?=$kredit->no_hp ?></td>
                </tr>
                

              </table>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-success" data-dismiss="modal"><i class="fas fa-times"></i>Close</button>
            </div>
          </div><i class="fas fa-exclamation-triangle"></i>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
