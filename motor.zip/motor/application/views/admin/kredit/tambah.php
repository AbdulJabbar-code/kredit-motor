              <?php
              echo validation_errors('<div class="alert alert-danger"><i class="fa fa-warning"></i>', '</div>');
              if (isset($error)) {
                # code...
                echo '<div class ="alert alert-warning">';
                echo $error;
                echo '</div>';
              }
              echo form_open_multipart(base_url('admin/kredit/tambah/'));

              ?>

              <div class="row">
                <div class="col-md-6">
								<div class="form-group">
								<label>Kode Kredit</label>
								<input type="text" name="kode_kredit" placeholder="Kode Kredit" class="form-control select2bs4" required style="width: 100%;">
								</div>
                  <div class="form-group">
                    <label> Nama Pelanggan </label>

                    <select class="form-control select2bs4" name="namak" id="namac" style="width: 100%;" required>
                      <?php
                      foreach ($pelanggan as $pel) {
                      ?>
                        <option value="<?= $pel->kode_pelanggan ?>">
                          <?= $pel->kode_pelanggan ?> - <?= $pel->nama_lengkap ?>
                        </option>
                      <?php
                      }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Motor</label>
                    <select class="form-control select2bs4" name="merekk" id="namac" style="width: 100%;" required>
                      <?php
                      foreach ($motor as $mot) {
                      ?>
                        <option value="<?= $mot->kode_motor ?>">
                          <?= $mot->kode_motor ?> - <?= $mot->merek ?> - Harga :<?= $mot->harga ?>
                          - Angsuran :<?= $mot->angsuran ?> - <?= $mot->per_bulan ?> Bulan
                        </option>
                      <?php
                      }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">


                  <!--   <div class="form-group ">
                    <label > angsuran </label>
                        <select class="form-control select2bs4" name="merekk" id="namac" style="width: 100%;" required>
                    <option selected="selected">----- Angsuran Motor -----</option>
                    <?php
                    foreach ($motor as $mot) {
                    ?>
                     <option value="<?= $mot->kode_motor ?>">
                      <?= $mot->kode_motor ?> - <?= $mot->merek ?> - <?= $mot->angsuran ?>
                     </option>
                     <?php
                    }
                      ?>
                </select>
                    
                  
                       
                    </div> -->
                  <!-- <div class="form-group ">
                    <label> Lama Cicilan </label>

                    <select class="form-control select2bs4" name="lamak" id="namac" style="width: 100%;" required>
                      <option selected="selected">----- Pilih Bunga -----</option>
                      <option value="12">12 Bulan</option>
                      <option value="18">18 bulan</option>
                      <option value="24">24 bulan</option>
                      <option value="30">30 bulan</option>
                      <option value="36">36 bulan</option>
                    </select>



                  </div> -->
                  <div class="form-group ">
                    <label> Tanggal </label>

                    <input type="date" class="form-control" required name="tanggalk" id="tanggalc" placeholder="Tanggal" value="<?= set_value('tanggal'); ?>">



                  </div>
                  <div class="form-group ">
                    <label> Konfirmasi</label>

                    <select class="form-control select2bs4" name="keterangank" id="namac" style="width: 100%;" required>
                      <option selected="selected">Menunggu Konfirmasi</option>

                      <option value="Terima">Terima</option>
                      <option value="Tolak">Tolak</option>


                    </select>
                  </div>
                  <div class="form-group ">
                    <button type="submit" name="simpan" class="btn btn-primary btn-xs">Simpan Data</button>
                    <button type="reset" name="reset" class="btn btn-secondary btn-xs" value="<?= base_url('') ?>">Batal</button>
                  </div>
                </div>
              </div>
              <?php
              echo form_close();
              ?>
