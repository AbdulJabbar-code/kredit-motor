<h2><center>Data User</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		<th>No</th>
		<th>Nama</th>
		<th>Email</th>
		<th>Username</th>
		<th>Photo</th>
		<th>keterangan</th>
	</tr>
	<?php 
	$no = 1;
	foreach($user as $row)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $row->nama; ?></td>
			<td><?php echo $row->email; ?></td>
			<td><?php echo $row->username; ?></td>
			<td><img src="<?= $row->photo257.'.jpeg' ?>"  width = "60" height="90"></td>
			<td><?php echo $row->ket; ?></td>
		</tr>
		<?php
	}
	?>
</table>