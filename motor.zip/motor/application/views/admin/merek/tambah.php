              
                    <?php 
                  echo validation_errors('<div class="alert alert-danger"><i class="fa fa-warning"></i>','</div>');
                  if (isset($error)) {
                    # code...
                    echo '<div class ="alert alert-warning">';
                    echo $error;
                    echo '</div>';
                  }
                  echo form_open_multipart(base_url('admin/motor/tambah'));

                   ?>

                    <div class="row">
                    <div class="col-md-6">
                       <div class="form-group ">
                    <label >Kode Motor</label>

                    <input type="text" class="form-control" id="motor" name="kodem" value="<?= set_value('kode_motor') ?>" placeholder="Kode Motor">
                  </div>
                  <div class="form-group">
                       <label >Merk</label>
                    
                      <input type="text" class="form-control" id="motor" name="merekm"  value="<?= set_value('merek') ?>" placeholder="Merk">
                    </div>
                    <div class="form-group">
                      <label >Type</label>
                       <input type="text" class="form-control" id="motor" name="typem"  value="<?= set_value('type') ?>" placeholder="Type">
                     </div>
                     <div class="form-group ">
                       <label>Harga</label>
                    
                      <input type="text" class="form-control" id="motor" name="hargam"  value="<?= set_value('harga') ?>" placeholder="Harga">
                          </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group ">
                    <label >Warna</label>
                    
                      <input type="text" class="form-control" id="motor" name="warnam"  value="<?= set_value('warna') ?>" placeholder="Warna">
                   </div>

                        <div class="form-group ">
                    <label >Photo</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar">
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                     
                  
                       <div class="form-group ">
                       
                      </div>
                        <button type="submit" name="simpan" class="btn btn-primary btn-xs" title="Simpan data">Simpan Data</button>
                        <button type="reset" name="reset" class="btn btn-secondary btn-xs">Batal</button>
                    </div>
                  </div>
                </div>
                  <?php 
                  echo form_close();
                   ?>


                 

                   

               



                 