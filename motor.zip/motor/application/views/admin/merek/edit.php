 <button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#edit<?=$motor->kode_motor  ?>">
                  <i class="fa fa-eye" title="Edit"></i>
                </button> 
      <div class="modal fade bd-example-modal" id="edit<?=$motor->kode_motor  ?>">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header badge-primary">
              <h4 class="modal-title">edit Data Motor : <?= $motor->merek?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            <?php

echo validation_errors('<div class="alert alert-danger"><i class="fa fa-times"></i>', '</div>');

if (isset($error)) {
  echo '<div class="alert alert-danger">';
  echo $error;
  echo '</div>';
}

echo form_open_multipart(base_url('admin/motor/edit/'.$motor->kode_motor));

?>

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800"><?= $title; ?></h1>

<!-- DataTales Example -->

     <div class="row">
                    <div class="col-md-6">
                       <div class="form-group ">
                    <label >Kode Motor</label>

                    <input type="text" class="form-control" id="motor" name="kodem" value="<?=$motor->kode_motor?>" disabled>
                  </div>
                  <div class="form-group">
                       <label >Merk</label>
                    
                      <input type="text" class="form-control" id="motor" name="merekm"  value="<?=$motor->merek?>">
                    </div>
                    <div class="form-group">
                      <label >Type</label>
                       <input type="text" class="form-control" id="motor" name="typem"  value="<?=$motor->type?>" >
                     </div>
                     <div class="form-group ">
                       <label>Harga</label>
                    
                      <input type="text" class="form-control" id="motor" name="hargam"  value="<?=$motor->harga?>" >
                          </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group ">
                    <label >Warna</label>
                    
                      <input type="text" class="form-control" id="motor" name="warnam"  value="<?=$motor->warna?>" >
                   </div>

                        <div class="form-group ">
                    <label >Photo</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" value="<?=$motor->photo?>">
                     
                    

                    </div>
                      <div class="form-group" style="padding-top: 20px;">
          <?php if ($motor->photo != "") { ?>
            <img src="<?= base_url('asset/img/motor/' . $motor->photo) ?>" class="img img-thumbnail" width="100" height="100">
          <?php } else {
            echo "Tidak Ada Photo";
          }  ?>
        </div>
                  
                       <div class="form-group ">
                       
                      </div>
                        <button type="submit" name="simpan" class="btn btn-primary btn-xs" title="Simpan data">Ubah</button>
                        <button type="reset" name="reset" class="btn btn-secondary btn-xs">Batal</button>
                          <?php include 'delete.php'; ?>
                    </div>
                  </div>
                </div>

  </div>


</div>
        <!-- /.modal-dialog -->
      </div>