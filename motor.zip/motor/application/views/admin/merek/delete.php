 <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#delete-<?= $motor->kode_motor ?>">
                 <i class="far fa-trash-alt" title="Hapus"></i>
                </button>
                 <div class="modal fade" id="delete-<?= $motor->kode_motor ?>">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Hapus Data Motor - <?= $motor->kode_motor ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p class="alert alert-danger"><i class="fas fa-excalation=triangle">Anda Yakin ingin Menghapus data Ini?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <a href="<?= base_url('admin/motor/delete/'.$motor->kode_motor) ?>" class="btn btn-danger"><i class="far fa-trash-o">Hapus</i></a>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              
            </div>
          </div>