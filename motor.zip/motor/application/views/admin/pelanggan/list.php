


<?php 
//Notifikasi

if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success"><i class="fa fa-check"></i>';
    echo $this->session->userdata('sukses');
    echo "</div>";
}
 ?>


<div class="card shadow mb-4">
  <h1>Data Pelanggan</h1>
  <div class="card-header">
    <p><a href="<?= base_url('admin/pelanggan/tambah') ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i>Tambah</a>
<a href="<?= base_url('admin/pelanggan/pdf') ?>" class="btn btn-secondary"><i class="fa fa-file"></i>Laporan</a>
</p>
  </div>

  <?php

  echo $this->session->flashdata('massage');

  ?>

  <div class="card-body">
    <div class="table-responsive">
       <table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
       <thead>
        <tr>
            <th>No</th>
            <th>Kode Pelanggan</th>
            <th>Foto Pelanggan</th>
            <th>Nama Lengkap</th>
            <th>Tempat- Tanggal Lahir</th>
            <th>Alamat - No HP</th>
           <th>FC KTP</th>
            <th>FC NPWP</th>
             <th>FC Slip Gaji</th>
             <th>FC KK</th>
              <th>Status</th>
            <th width="15%">Action</th>
        </tr>
    </thead>
   <tbody> <?php $i = +1; foreach($pelanggan as $pelanggan){ ?>
        <tr>
            <td><?= $i ?></td>
            <td><?= $pelanggan->kode_pelanggan ?></td>
            <td><?php if ($pelanggan->foto!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->foto) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
            <td><?= $pelanggan->nama_lengkap ?></td>
            <td><?=   $pelanggan->tmp_lahir  ?>-<?= $pelanggan->tgl_lahir ?> </td>
            <td><?=   $pelanggan->alamat  ?>-<?= $pelanggan->no_hp ?> </td>
           
           
           
            <td><?php if ($pelanggan->ktp!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->ktp) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
          
               <td><?php if ($pelanggan->npwp!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->npwp) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
            
               <td><?php if ($pelanggan->slip_gaji!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->slip_gaji) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
                     <td><?php if ($pelanggan->kk!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->kk) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
            <td><?= $pelanggan->keterangan ?></td>
               <td>     
                <?php include 'edit.php'; ?>

              
            </td>
            <td> <?php include 'delete.php'; ?></td>
            
        </tr>

        <?php $i++; } ?> </tbody>
      </table>
    </div>
  </div>
</div>
      
    </tbody>
 <script type="text/javascript" src="<?= base_url() ?>asset/admin/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>asset/admin/datatables/datatables.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>asset/admin/datatables/lib/js/dataTables.bootstrap.min.js"></script>
    <script>
    <script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
</script>

</table>
