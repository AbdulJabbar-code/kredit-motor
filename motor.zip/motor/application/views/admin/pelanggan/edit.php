 <button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#edit<?=$pelanggan->kode_pelanggan  ?>">
                  <i class="fa fa-eye" title="Edit"></i>
                </button> 
      <div class="modal fade bd-example-modal" id="edit<?=$pelanggan->kode_pelanggan  ?>">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header badge-primary">
              <h4 class="modal-title">Edit Data pelanggan : <?= $pelanggan->nama_lengkap?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            <?php

echo validation_errors('<div class="alert alert-danger"><i class="fa fa-times"></i>', '</div>');

if (isset($error)) {
  echo '<div class="alert alert-danger">';
  echo $error;
  echo '</div>';
}

echo form_open_multipart(base_url('admin/pelanggan/edit/'.$pelanggan->kode_pelanggan));

?>

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800"><?= $title; ?></h1>

<!-- DataTales Example -->

     <div class="row">
                    <div class="col-md-6">
                       <div class="form-group ">
                    <label >Kode Pelanggan</label>

                    <input type="text" class="form-control" id="pelanggan" name="kode_pelanggan" value="<?=$pelanggan->kode_pelanggan ?>" disabled>
                  </div>
                  <div class="form-group">
                       <label >Nama Lengkap</label>
                    
                      <input type="text" class="form-control" id="pelanggan" name="nama_lengkap"  value="<?=$pelanggan->nama_lengkap ?>" placeholder="Nama Lengkap">
                    </div>
                    <div class="form-group">
                      <label >Alamat</label>
                       <input type="text" class="form-control" id="pelanggan" name="alamat"  value="<?=$pelanggan->alamat ?>" placeholder="Alamat">
                     </div>
                     <div class="form-group ">
                       <label>No Handphone </label>
                    
                      <input type="text" class="form-control" id="pelanggan" name="no_hp"  value="<?=$pelanggan->no_hp ?>" placeholder="No Handphone">
                          </div>
                          <div class="form-group ">
                       <label>Tanggal Lahir </label>
                    
                      <input type="date" class="form-control" id="pelanggan" name="tgl_lahir"  value="<?=$pelanggan->tgl_lahir ?>" placeholder="Tanggal Lahir">
                          </div>

                          <div class="form-group ">
                    <label >foto </label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                   
                  
                      
                    </div>
                    </div>
                    <div class="col-md-6">
                    
                     <div class="form-group ">
                       <label>Tempat Lahir </label>
                    
                      <input type="text" class="form-control" id="pelanggan" name="tmp_lahir"  value="<?=$pelanggan->tmp_lahir ?>" placeholder="Tempat Lahir">
                          </div>

                        <div class="form-group ">
                    <label >foto Copy KTP</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                   
                  
                      
                    </div>
                    <div class="form-group ">
                    <label >foto Copy KK</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                   
                  
                      
                    </div>
                    <div class="form-group ">
                    <label >foto Copy NPWP</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                    
                  
                    </div>
                     <div class="form-group ">
                    <label >foto Copy Slip Gaji</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                  
</div>
                           <div class="form-group ">
                    <label >Status</label>
                    
                  <select class="form-control " name="keterangan"  >
                      
                      <option value="<?=$pelanggan->keterangan ?>">Kawin</option>
                      <option value="<?=$pelanggan->keterangan ?>">Belum Kawin</option>
                      
                       
                     </select>
                   </div>
                     <div class="form-group ">
                         <button type="submit" name="simpan" class="btn btn-primary btn-xs">Simpan Data</button>
                        <button type="reset" name="reset" class="btn btn-secondary btn-xs">Batal</button>
                      </div>
                  </div>
                </div>

  </div>


</div>
        <!-- /.modal-dialog -->
      </div>