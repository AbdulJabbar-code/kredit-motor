              
                    <?php 
                  echo validation_errors('<div class="alert alert-danger"><i class="fa fa-warning"></i>','</div>');
                  if (isset($error)) {
                    # code...
                    echo '<div class ="alert alert-warning">';
                    echo $error;
                    echo '</div>';
                  }
                  echo form_open_multipart(base_url('admin/pelanggan/tambah/'));

                   ?>
                    <h1>Tambah Data Pelanggan</h1>
                    <div class="row">
                    <div class="col-md-6">
                       <div class="form-group ">
                    <label >Kode Pelanggan</label>

                    <input type="text" class="form-control" id="pelangan" name="kode_pelanggan" value="<?= set_value('kode_pelanggan') ?>" placeholder="Kode Pelanggan" required>
                  </div>
                  <div class="form-group">
                       <label >Nama Lengkap</label>
                    
                      <input type="text" class="form-control" id="pelangan" name="nama_lengkap"  value="<?= set_value('nama_lengkap') ?>" placeholder="Nama Lengkap">
                    </div>
                    <div class="form-group">
                      <label >Alamat</label>
                       <input type="text" class="form-control" id="pelangan" name="alamat"  value="<?= set_value('alamat') ?>" placeholder="Alamat">
                     </div>
                     <div class="form-group ">
                       <label>No Handphone </label>
                    
                      <input type="text" class="form-control" id="pelangan" name="no_hp"  value="<?= set_value('no_hp') ?>" placeholder="No Handphone">
                          </div>
                          <div class="form-group ">
                       <label>Tanggal Lahir </label>
                    
                      <input type="date" class="form-control" id="pelangan" name="tgl_lahir"  value="<?= set_value('no_hp')?>" placeholder="Tanggal Lahir">
                          </div>

                          <div class="form-group ">
                    <label >foto </label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="foto">Choose file</label>
                    

                    </div>
                   
                  
                      
                    </div>
                    </div>
                    <div class="col-md-6">
                    
                     <div class="form-group ">
                       <label>Tempat Lahir </label>
                    
                      <input type="text" class="form-control" id="pelangan" name="tmp_lahir"  value="" placeholder="Tempat Lahir">
                          </div>

                        <div class="form-group ">
                    <label >foto Copy KTP</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="ktp">Choose file</label>
                    

                    </div>
                   
                  
                      
                    </div>
                    <div class="form-group ">
                    <label >foto Copy KK</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="kk">Choose file</label>
                    

                    </div>
                   
                  
                      
                    </div>
                    <div class="form-group ">
                    <label >foto Copy NPWP</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="npwp">Choose file</label>
                    

                    </div>
                    
                  
                    </div>
                     <div class="form-group ">
                    <label >foto Copy Slip Gaji</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="slip_gaji">Choose file</label>
                    

                    </div>
                  
</div>
                           <div class="form-group ">
                    <label >Status</label>
                    
                  <select class="form-control " name="keterangan"  >
                      
                      <option value="Kawin">Kawin</option>
                      <option value="Belum Kawin">Belum Kawin</option>
                      
                       
                     </select>
                   </div>
                     <div class="form-group ">
                         <button type="submit" name="simpan" class="btn btn-primary btn-xs">Simpan Data</button>
                        <button type="reset" name="reset" class="btn btn-secondary btn-xs">Batal</button>
                      </div>
                  </div>
                </div>
                
                  <?php 
                  echo form_close();
                   ?>


                 