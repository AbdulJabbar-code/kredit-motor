<button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#delete-<?= $pelanggan->kode_pelanggan ?>">
                 <i class="far fa-trash-alt" title="Hapus"></i>
                </button>
                 <div class="modal fade" id="delete-<?= $pelanggan->kode_pelanggan ?>">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Hapus pelanggan - <?= $pelanggan->kode_pelanggan ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p class="alert alert-danger"><i class="fas fa-excalation=triangle">Anda Yakin ingin Menghapus data Ini?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <a href="<?= base_url('admin/pelanggan/delete/'.$pelanggan->kode_pelanggan) ?>" class="btn btn-danger"><i class="far fa-trash-o">Hapus</i></a>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              
            </div>
          </div>