<h2><center>Data Pelanggan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		 <th>#</th>
            <th>Kode Pelanggan</th>
            <th>Foto Pelanggan</th>
            <th>Nama Lengkap</th>
            <th>Tempat- Tanggal Lahir</th>
            <th>Alamat - No HP</th>
           <th>FC KTP</th>
            <th>FC NPWP</th>
             <th>FC Slip Gaji</th>
             <th>FC KK</th>
              <th>Status</th>
	</tr>
	<?php 
	$no = 1;
	foreach($pelanggan as $pelanggan)
	{
		?>
		<tr>
			<td><?= $no ?></td>
            <td><?= $pelanggan->kode_pelanggan ?></td>
            <td><?php if ($pelanggan->foto!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->foto) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
            <td><?= $pelanggan->nama_lengkap ?></td>
            <td><?=   $pelanggan->tmp_lahir  ?>-<?= $pelanggan->tgl_lahir ?> </td>
            <td><?=   $pelanggan->alamat  ?>-<?= $pelanggan->no_hp ?> </td>
           
           
           
            <td><?php if ($pelanggan->ktp!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->ktp) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
          
               <td><?php if ($pelanggan->npwp!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->npwp) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
            
               <td><?php if ($pelanggan->slip_gaji!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->slip_gaji) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
                     <td><?php if ($pelanggan->kk!="") { ?>
                        <img src="<?= base_url('asset/img/pelanggan/'.$pelanggan->kk) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
            <td><?= $pelanggan->keterangan ?></td>
              
		</tr>
		<?php
	}
	?>
</table>