<?php
//Notifikasi

if ($this->session->flashdata('sukses')) {
  echo '<div class="alert alert-success"><i class="fa fa-check"></i>';
  echo $this->session->userdata('sukses');
  echo "</div>";
}
?>


<div class="card shadow mb-4">

	<div class="card-header">
		<a href="<?= base_url('admin/cicilan/pelanggan_motor') ?>" class="btn btn-warning btn-xs"><i
				class="fas fa-arrow-alt-circle-left"></i> Kembali</a>
		<?php if(!$pelanggan_cicilan) : ?>
		<a href="<?= base_url('admin/cicilan/add/kode_pelanggan/' . $kode . '/kode_kredit/' . $kode_kredit ) ?>"
			class="btn btn-primary btn-xs"><i class="fa fa-plus"></i>Tambah</a>
		<?php endif; ?>
		<a href="<?= base_url('admin/cicilan/pdf') ?>" class="btn btn-secondary"><i class="fa fa-file"></i>Laporan</a>
	</div>

	<?php

  echo $this->session->flashdata('massage');

  ?>

	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
				<thead>
					<tr>
						<th>#</th>
						<th>No Bayar</th>
						<th>Kode kredit</th>
						<th>Nama Pelanggan</th>
						<th>Angsuran Ke</th>
						<th>Tanggal Bayar</th>
						<th>Jumlah yang dibayar</th>
						<th>Keterangan</th>
						<th width="15%">Action</th>
					</tr>
				</thead>
				<tbody> <?php $i = 1;
                foreach ($cicilan as $cicilan) { ?>
					<tr>
						<td><?= $i ?></td>
						<td><?= $cicilan->no_bayar ?></td>
						<td><?= $cicilan->kode_kredit_id ?></td>
						<td><?= $cicilan->nama_lengkap  ?></td>
						<td><?= $cicilan->anggsuran ?></td>
						<td><?= $cicilan->tanggal_bayar ?></td>
						<td><?= $cicilan->jumlah_bayar_cicilan  ?></td>
						<td><?= $cicilan->keterangan_cicilan ?></td>
						<td>
							<div class="d-flex">
								<a href="<?= base_url('admin/cicilan/edit/' . $cicilan->no_bayar . '/nama/' . $cicilan->nama_lengkap . '/kode_pelanggan/' . $cicilan->kode_pelanggan . '/kode_kredit/' . $cicilan->kode_kredit_id) ?>"
									class="btn btn-success"><i class="fa fa-pen"></i></a>
								<?php if($cicilan->bulan_ini == 0) : ?>
								<a href="<?= base_url('admin/cicilan/add_cicilan/' . $cicilan->no_bayar . '/kode_kredit/' . $cicilan->kode_kredit . '/kode_pelanggan/' . $cicilan->kode_pelanggan) ?>"
									class="btn ml-2 btn-danger"><i class="fa fa-check"></i></a>
								<?php else: ?>
								<a href="#" class="btn ml-2 btn-primary"><i class="fas fa-check-double"></i></a>
								<?php endif; ?>
							</div>
						</td>
					</tr>
					<?php $i++;
                } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

</tbody>
<script type="text/javascript" src="<?= base_url() ?>asset/admin/js/jquery.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>asset/admin/datatables/datatables.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>asset/admin/datatables/lib/js/dataTables.bootstrap.min.js">
</script>
<script>
	$(document).ready(function () {
		$('#tabel-data').DataTable();
	});

</script>

</table>
