<?php
echo validation_errors('<div class="alert alert-danger"><i class="fa fa-warning"></i>', '</div>');
if (isset($error)) {
  # code...
  echo '<div class ="alert alert-warning">';
  echo $error;
  echo '</div>';
}

echo form_open_multipart(base_url('admin/cicilan/tambah/'));
?>
<h1></h1>
<div class="row">
  <div class="col-md-6">

    <div class="form-group">
      <label>Kode Kredit</label>
			<input type="text" class="form-control select2bs4" name="kode_kredit" id="kokre" style="width: 100%;" readonly required placeholder="" value="">
    </div>

    <div class="form-group">
      <label>Nama</label>
			<input type="text" name="user" id="nama" class="form-control select2bs4" style="width: 100%;" readonly required value="<?= $kode_nama; ?>" placeholder="<?= $nama ?>">
    </div>
  </div>
  <div class="col-md-6">
    <div class="form-group ">
      <label>Tanggal Bayar</label>
      <input type="date" class="form-control" name="tabay" id="tanggal_bayar" placeholder="Tanggal Masuk Buku" value="<?= date('Y-m-d') ?>" required>
    </div>
		<div class="form-group">
      <label>Kode Motor</label>
      <input type="text" class="form-control select2bs4" name="angsuran_ke" value="1" disabled placeholder="Angsuran Ke" id="angsuran" style="width: 100%;" required>
    </div>
    <div class="form-group ">
      <button type="submit" name="simpan" class="btn btn-primary btn-xs">Simpan Data</button>
      <button type="reset" name="reset" class="btn btn-secondary btn-xs">Batal</button>
    </div>
  </div>
</div>
<?php
echo form_close();
?>
