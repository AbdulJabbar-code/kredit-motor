<?php
//Notifikasi

if ($this->session->flashdata('sukses')) {
  echo '<div class="alert alert-success"><i class="fa fa-check"></i>';
  echo $this->session->userdata('sukses');
  echo "</div>";
}
?>


<div class="card shadow mb-4">

  <?php

  echo $this->session->flashdata('massage');

  ?>

  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>#</th>
            <th>Kode Kredit</th>
            <th>Kode Motor</th>
            <th>Nama Pelanggan</th>
            <th>Alamat</th>
            <th>Status</th>
            <th width="15%">Action</th>
          </tr>
        </thead>
        <tbody> <?php $i = 1;
                foreach ($pelanggan as $cicilan) { ?>
            <tr>
              <td><?= $i ?></td>
              <td><?= $cicilan->kode_kredit ?></td>
              <td><?= $cicilan->kode_motor  ?></td>
              <td><?= $cicilan->nama_lengkap  ?></td>
              <td><?= $cicilan->alamat ?></td>
              <td><?php
                        if($cicilan->angsuran>=12){
                          $status= 'LUNAS';
                        }elseif($cicilan->angsuran<=12){
                          $status= 'BELOM LUNAS';
                        }else{
                          $status= 'BELUM ADA CICILAN';
                        } echo $status;

                        ?></td>
              <td>
							<div class="d-flex">
								<a href="<?= base_url('admin/cicilan/index/kode_pelanggan/' . $cicilan->kode_pelanggan) . '/kode_kredit/' . $cicilan->kode_kredit ?>" class="btn btn-success"><i class="fa fa-eye"></i></a>
							</div>
              </td>
            </tr>
          <?php $i++;
                } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</tbody>
<script type="text/javascript" src="<?= base_url() ?>asset/admin/js/jquery.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>asset/admin/datatables/datatables.min.js"></script>
<script type="text/javascript" src="<?= base_url() ?>asset/admin/datatables/lib/js/dataTables.bootstrap.min.js"></script>
<script>
  $(document).ready(function() {
    $('#tabel-data').DataTable();
  });
</script>

</table>
