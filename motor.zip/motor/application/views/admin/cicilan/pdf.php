<h2><center>Data Cicilan Pelanggan</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		 <th>#</th>
           <th>No Bayar</th>
            <th>Kode kredit</th>
            <th>Nama Pelanggan</th>
            <th>Angsuran Ke</th>
            <th>Tanggal Bayar</th>
            <th>Jumlah yang dibayar</th>
            <th>Keterangan</th>
	</tr>
	<?php 
	$no = 1;
	foreach($cicilan as $cicilan)
	{
		?>
		<tr>
			<td><?= $no ?></td>
            <td><?= $cicilan->no_bayar ?></td>
              <td><?= $cicilan->kode_kredit ?></td>
              <td><?= $cicilan->nama_lengkap  ?></td>
              <td><?= $cicilan->anggsuran ?></td>
              <td><?= $cicilan->tanggal_bayar ?></td>
              <td><?= $cicilan->jumlah_bayar_cicilan  ?></td>
              <td><?= $cicilan->keterangan_cicilan ?></td>
              
		</tr>
		<?php
	}
	?>
</table>