<?php

if ($this->session->userdata('username') == "" && $this->session->userdata('akses_level') == "") {
  $this->session->set_flashdata('massage', '<div class="alert alert-danger" role="alert"><i class="fa fa-times">Silahkan login terlebih dahulu.!</i></div>');
  redirect(base_url('login'), 'refresh');
}

require_once 'head.php';
require_once 'sidebar.php';
require_once 'navbar.php';
require_once 'content.php';
require_once 'footer.php';
require_once 'wrapper.php';
?>