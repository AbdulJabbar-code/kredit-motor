


<?php 
//Notifikasi

if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success"><i class="fa fa-check"></i>';
    echo $this->session->userdata('sukses');
    echo "</div>";
}
 ?>


<div class="card shadow mb-4">
 <h1>Daftar Motor</h1>
  <div class="card-header">
    <p><a href="<?= base_url('admin/motor/tambah') ?>" class="btn btn-success btn-xs"><i class="fa fa-plus"></i>Tambah</a>
<a href="<?= base_url('admin/motor/pdf') ?>" class="btn btn-secondary"><i class="fa fa-file"></i>Laporan</a>
</p>
  </div>

  <?php

  echo $this->session->flashdata('massage');

  ?>

  <div class="card-body">
    <div class="table-responsive">
       <table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
       <thead>
        <tr>
            <th>#</th>
            <th>Kode Motor</th>
            <th>Merk</th>
            <th>Type</th>
            <th>Warna</th>
            <th>Harga</th>
            <th>Dp(20% dari harga)</th>
            <th>Angsuran(per Bulan)</th>
            <th>photo</th>
            <th width="15%">Action</th>
        </tr>
    </thead>
   <tbody>
     <?php $i = 1; foreach($motor as $motor){ ?>
        <tr>
            <td><?= $i ?></td>
            <td><?= $motor->kode_motor ?></td>
            <td><?= $motor->merek ?></td>
            <td><?=   $motor->type  ?></td>
            <td><?= $motor->warna ?></td>
           
            <td><?= $motor->harga ?></td>
            <td><?= $motor->dp ?></td>
            <td><?= number_format($motor->angsuran,0) . ' X ' . $motor->per_bulan . ' Bulan'?></td>
            <td><?php if ($motor->photo!="") { ?>
                        <img src="<?= base_url('asset/img/motor/'.$motor->photo) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
            <td>
                   <?php include 'edit.php'; ?>      
            </td>
            <td> <?php include 'delete.php'; ?></td>
        </tr>

        <?php $i++; } ?> 
   </tbody>
      </table>
    </div>
  </div>
</div>
      
    </tbody>
 
    <script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
</script>

</table><!-- 
data nav -->
 <!-- <li class="nav-item">
    <a class="nav-link" href="<?= base_url('admin/merek_motor') ?>">
      <i class="fas fa-fw fa-check"></i>
      <span>Merek Motor</span>
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?= base_url('admin/jenis_motor') ?>">
      <i class="fas fa-fw fa-check"></i>
      <span>Jenis Motor</span>
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?= base_url('admin/pembelian') ?>">
      <i class="fas fa-fw fa-check"></i>
      <span>pembelian</span>
    </a>
  </li> -->
