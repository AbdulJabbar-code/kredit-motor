              
                    <?php 
                  echo validation_errors('<div class="alert alert-danger"><i class="fa fa-warning"></i>','</div>');
                  if (isset($error)) {
                    # code...
                    echo '<div class ="alert alert-warning">';
                    echo $error;
                    echo '</div>';
                  }
                  echo form_open_multipart(base_url('admin/motor/tambah'));

                   ?>
                        <h1>Tambah Daftar Motor</h1>
                    <div class="row">
                    <div class="col-md-6">
                    
                       <div class="form-group ">
                    <label >Kode Motor</label>

                    <input type="text" class="form-control" id="motor" name="kode_motor" value="<?= $kode_motor ?>" readonly>
                    <?= form_error('kode_motor', '<div class="text-danger small ml-3">', '</div>') ?>
                  </div>
                  <div class="form-group">
                       <label >Merk</label>
                    
                      <input type="text" class="form-control" id="motor" name="merekm"  value="<?= set_value('merek') ?>" placeholder="Merk" required>
                    </div>
                    <div class="form-group">
                      <label >Type</label>
                       <input type="text" class="form-control" id="motor" name="typem"  value="<?= set_value('type') ?>" placeholder="Type" required>
                     </div>
                     <div class="form-group ">
                       <label>Harga</label>
                    
                      <input type="text" class="form-control" id="harga" name="hargam"  value="<?= set_value('harga') ?>" placeholder="Harga" required>
                          </div>
                    </div>
                    <div class="col-md-6">
                       <div class="form-group ">
                    <label >Dp 20% dari harga beli</label>
                 
                   </div>
                    <div class="form-group ">
                    <label >Angsuran</label>
                    
                     <select class="form-control select2bs4" name="per_bulan"value="<?= set_value('per_bulan') ?>" id="namac" style="width: 100%;" required>
                    <option selected="selected">----- Pilih Angsuran -----</option>
                   
                     <option value="12"> x 12 Bulan</option>
                      <option value="18"> x 18 bulan</option>
                       <option value="24"> x 24 Bulan</option>
                        <option value="30"> x 30 Bulan</option>
                         <option value="36"> x 36 Bulan</option>
                    
                </select>
                   </div>
                      <div class="form-group ">
                    <label >Warna</label>
                    
                      <input type="text" class="form-control" id="motor" name="warnam"  value="<?= set_value('warna') ?>" placeholder="Warna" required>
                   </div>

                        <div class="form-group ">
                    <label >Photo</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*" required>
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                     
                  
                       <div class="form-group ">
                       
                      </div>
                        <button type="submit" name="simpan" class="btn btn-primary btn-xs" title="Simpan data">Simpan Data</button>
                        <button type="reset" name="reset" class="btn btn-secondary btn-xs">Batal</button>
                    </div>
                  </div>
                </div>
								<script>
									const motor = document.getElementById('harga');
									motor.addEventListener('changer',() => {
										console.log(motor.value);
									});
								</script>
                  <?php 
                  echo form_close();
                   ?>