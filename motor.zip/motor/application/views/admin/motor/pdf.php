<h2><center>Data User</center></h2>
<hr/>
<table border="1" width="100%" style="text-align:center;">
	<tr>
		 <th>#</th>
            <th>Kode Motor</th>
            <th>Merk</th>
            <th>Type</th>
            <th>Warna</th>
            <th>Harga</th>
            <th>Dp</th>
            <th>Angsuran(per Bulan)</th>
            <th>photo</th>
	</tr>
	<?php 
	$no = 1;
	foreach($motor as $motor)
	{
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			 <td><?= $motor->kode_motor ?></td>
            <td><?= $motor->merek ?></td>
            <td><?=   $motor->type  ?></td>
            <td><?= $motor->warna ?></td>
           
            <td><?= $motor->harga ?></td>
            <td><?= $motor->dp ?></td>
            <td><?= $motor->angsuran ?></td>
            <td><?php if ($motor->photo!="") { ?>
                        <img src="<?= base_url('asset/img/motor/'.$motor->photo) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
		</tr>
		<?php
	}
	?>
</table>