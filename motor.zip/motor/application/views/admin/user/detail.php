 <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#detail<?=$user->id_user257  ?>">
                  <i class="fa fa-eye">Detail</i>
                </button>
      <div class="modal fade" id="detail<?=$user->id_user257  ?>">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header badge-primary">
              <h4 class="modal-title">Detail Data user : <?= $user->nama?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <table class="table table-bordered table-striped">
               
                <tr>
                  <th>Nama</th>
                  <td><?= $user->nama ?></td>
                </tr>
                <tr>
                  <th>Email</th>
                  <td><?= $user->email ?></td>
                </tr>
                <tr>
                  <th>Username</th>
                  <td><?= $user->username ?></td>
                </tr>
                <tr>
                  <th>Akses level </th>
                  <td><?= $user->akses_level ?></td>
                </tr>
                
               
               
                <tr>
                  <th>Tanggal</th>
                  <td><?=date("d F Y", strtotime( $user->tanggal)) ?></td>
                </tr>
                <tr>
                  <th>Photo</th>
                  <td>
                    <img src="<?= base_url('asset/user/'.$user->photo)  ?>" class="img img-thumbnail" width="100" height="130">
                  </td>
                </tr>

              </table>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-success" data-dismiss="modal"><i class="fas fa-times"></i>Close</button>
            </div>
          </div><i class="fas fa-exclamation-triangle"></i>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>