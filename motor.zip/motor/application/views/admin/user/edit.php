 <button type="button" class="btn btn-secondary btn-xs" data-toggle="modal" data-target="#edit<?=$user->id_user257  ?>">
                  <i class="fa fa-book">detail</i>
                </button> 
      <div class="modal fade bd-example-modal" id="edit<?=$user->id_user257  ?>">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header badge-primary">
              <h4 class="modal-title">edit Data user : <?= $user->nama?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
               <?php 
                  echo validation_errors('<div class="alert alert-danger"><i class="fa fa-warning"></i>','</div>');

                  echo form_open(base_url('admin/user/edit/'.$user->id_user257));

                   ?>    

                    <div class="row">
                    <div class="col-md-6">
                       <div class="form-group ">
                    <label >Nama</label>

                    <input type="text" class="form-control" id="nama" name="nama" value='<?= $user->nama ?>'>
                  </div>
                  <div class="form-group">
                       <label >Email</label>
                    
                      <input type="email" class="form-control" id="email" name="email"  value='<?= $user->email ?>'>
                    </div>
                    <div class="form-group">
                      <label >Username</label>
                       <input type="text" class="form-control" id="user" name="username"  value='<?= $user->username ?>'>
                     </div>
                     <div class="form-group ">
                       <label>Password</label>
                    
                      <input type="password" class="form-control" id="pass" name="password"  value='<?= $user->password ?>' >
                          </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group ">
                    <label >level Hak Akses</label>
                    
                     <select class="form-control " name="akses_level"  value='<?= $user->akses_level ?>' >
                      
                      <option value="admin">Admin</option>
                      <option value="user">User</option>
                      
                       
                     </select>
                   </div>
                      <div class="form-group ">
                    <label >Photo</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                   <div class="form-group ">
                      <label >KETERAGAN</label>
                        <input class="form-control"  name="keterangan"  value='<?= $user->ket ?>'></input>
                       </div>
                       <div class="form-group ">
                         <button type="submit" name="simpan" class="btn btn-success" value="edit Data">Edit Data</button>
                        <button type="reset" name="reset" class="btn btn-success">Batal</button>
                      </div>
                    </div>
                  </div>
                  <?php 
                  echo form_close();
                   ?>

        <!-- /.modal-dialog -->
      </div>