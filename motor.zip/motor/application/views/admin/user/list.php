


<?php 
//Notifikasi

if($this->session->flashdata('sukses')){
    echo '<div class="alert alert-success"><i class="fa fa-check"></i>';
    echo $this->session->userdata('sukses');
    echo "</div>";
}
 ?>


<div class="card shadow mb-4">
 <h1>Daftar Petugas</h1>
  <div class="card-header">
    <p><a href="<?= base_url('admin/user/tambah') ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i>Tambah</a>
</p>
  </div>

  <?php

  echo $this->session->flashdata('massage');

  ?>

  <div class="card-body">
    <div class="table-responsive">
       <table class="table table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
       <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Usernamee - Level</th>
            <td>Photo</td>
            <th>Keterangan</th>
            <th width="15%">edit</th>
            <th>hapus</th>
        </tr>
    </thead>
    <tbody>
   <?php $i = +1; foreach($user as $user){ ?>
        <tr>
            <td><?= $i ?></td>
            <td><?= $user->nama ?></td>
            <td><?= $user->email ?></td>
            <td><?= $user->username ?> - <?= $user->akses_level ?></td>
            <td><?php if ($user->photo!="") { ?>
                        <img src="<?= base_url('asset/user/'.$user->photo) ?>" class="img img-thumbnail" width = "60" height="90">
                    <?php } else{echo "Tidak ada";}?></td>
            <td><?= $user->ket ?></td>
            <td>
               <?php include 'edit.php' ?>
                <?php include 'detail.php'; ?>
                
            </td>
            <td><?php include 'delete.php'; ?></td>
        </tr>


            <?php $i++; } ?> 

        </tbody>
      </table>
    </div>
  </div>
</div>
      
    </tbody>
 <script type="text/javascript" src="<?= base_url() ?>asset/admin/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>asset/admin/datatables/datatables.min.js"></script>
    <script type="text/javascript" src="<?= base_url() ?>asset/admin/datatables/lib/js/dataTables.bootstrap.min.js"></script>
    <script>
    <script>
    $(document).ready(function(){
        $('#tabel-data').DataTable();
    });
</script>

</table>
