 <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?= $user->id_user257 ?>">
                 <i class="far fa-trash-alt">Hapus</i>
                </button>
                 <div class="modal fade" id="delete<?= $user->id_user257 ?>">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Hapus Data user - <?= $user->id_user257 ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p class="alert alert-danger"><i class="fas fa-excalation=triangle">Anda Yakin ingin Menghapus data Ini?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <a href="<?= base_url('admin/user/delete/'.$user->id_user257) ?>" class="btn btn-danger"><i class="far fa-trash-alt">Hapus</i></a>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              
            </div>
          </div>