              
                    <?php 
                  echo validation_errors('<div class="alert alert-danger"><i class="fa fa-warning"></i>','</div>');
                  if (isset($error)) {
                    # code...
                    echo '<div class ="alert alert-warning">';
                    echo $error;
                    echo '</div>';
                  }
                  echo form_open_multipart(base_url('admin/user/tambah/'));

                   ?>
                    <h1>Tambah Daftar Petugas</h1>
                    <div class="row">
                    <div class="col-md-6">
                       <div class="form-group ">
                    <label >Nama</label>

                    <input type="text" class="form-control" id="nama" name="nama" value="<?= set_value('nama') ?>" placeholder="Nama Lengkap" required>
                  </div>
                  <div class="form-group">
                       <label >Email</label>
                    
                      <input type="email" class="form-control" id="email" name="email"  value="<?= set_value('email') ?>" placeholder="Email">
                    </div>
                    <div class="form-group">
                      <label >Username</label>
                       <input type="text" class="form-control" id="user" name="username"  value="<?= set_value('username') ?>" placeholder="Username">
                     </div>
                     <div class="form-group ">
                       <label>Password</label>
                    
                      <input type="password" class="form-control" id="pass" name="password"  value="<?= set_value('password') ?>" placeholder="Password">
                          </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group ">
                    <label >level Hak Akses</label>
                    
                     <select class="form-control " name="akses_level"  >
                      
                      <option value="admin">Admin</option>
                      <option value="user">User</option>
                      
                       
                     </select>
                   </div>

                        <div class="form-group ">
                    <label >Photo</label>
                    
                      <div class="custom-file">
                      <input type="file" name="gambar" class="custom-file-input" id="gambar" accept="image/*">
                      <label class="custom-file-label" for="gambar">Choose file</label>
                    

                    </div>
                    <div class="input-group-append">
                      <span class="input-group-text">upload</span>
                    </div>  
                   <div class="form-group ">
                      <label >KETERANGAN</label>
                        <input class="form-control"  name="keterangan"  value="<?= set_value('keterangan') ?>" placeholder=""></input>
                       </div>
                       <div class="form-group ">
                         <button type="submit" name="simpan" class="btn btn-success">Simpan Data</button>
                        <button type="reset" name="reset" class="btn btn-success">Batal</button>
                      </div>
                    </div>
                  </div>
                  <?php 
                  echo form_close();
                   ?>


                 

                   

               



                 