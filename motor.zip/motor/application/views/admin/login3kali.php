<?php
//login.php
session_start();

if (isset($_SESSION['username'])) {
  if (isset($_GET['logout'])) unset($_SESSION['username']);
  header("location: index.php");
} else {
  if ($_POST) {
    //asumsi username and password hasil fetched form database
    $username = "admin";
    $password = "21232f297a57a5a743894a0e4a801fc3"; //admin
    //password di atas hasil md5("admin");

    if ($_POST['uname'] == $username) { //bandingkan username
      if (md5($_POST['passwd']) == $password) { //bandingkan password
        //sukses
        unset($_SESSION['failed']); //hapus failed
        unset($_SESSION['delayto']); //hapus delayto
        $_SESSION['username'] = $username; //catat username
        header("location: index.php"); //ke halaman utama
      }
    }
    //failed catat sudah berapa kali
    $message = "Username/password tidak match";
    if (!isset($_SESSION['failed'])) $_SESSION['failed'] = 0;
    $_SESSION['failed']++; //faileb bertambah

    //delay sebanyak 2 pangkat gagal
    $delay = pow(2, $_SESSION['failed']);
    $_SESSION['delayto'] = strtotime("+ {$delay} seconds");
  }
}
?>
<h2>Login</h2>
<?php
if (isset($message)) echo $message . "<br/>";
if (isset($_SESSION['delayto'])) $delay = $_SESSION['delayto'] - time();
else $delay = 0;

if ($delay > 0) : ?>

  <p>
    Sudah <?php echo $_SESSION['failed']; ?> kali gagal.<br />
    Silakan coba
    <span id="delay"><?php echo $delay; ?></span>.
  </p>
  <script type="text/javascript">
    var seconds;
    var temp;

    function countdown() {
      seconds = document.getElementById('delay').innerHTML;
      seconds = parseInt(seconds, 10);

      if (seconds == 1) {
        temp = document.getElementById('delay');
        temp.innerHTML = "<a href='login.php'>login</a>";
        return;
      }

      seconds--;
      temp = document.getElementById('delay');
      temp.innerHTML = seconds + " detik lagi";
      timeoutMyOswego = setTimeout(countdown, 1000);
    }

    countdown();
  </script>

<?php else : ?>

  <form method="POST">
    Username: <br />
    <input type="text" name="uname"><br />
    Password :<br />
    <input type="password" name="passwd"><br />
    <input type="submit" value="Submit">
  </form>

<?php endif; ?>