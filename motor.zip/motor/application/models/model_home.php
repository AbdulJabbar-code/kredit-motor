 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_home extends CI_Model {
	public function __construct()
  {
    parent::__construct();
    $this->load->database();
  }

	// Menampilkand data berita
    public function beranda($read = FALSE) {
   

    $this->db->select('*');
    $this->db->from('buku257');
    $this->db->join('jenis257', 'buku257.idjenis257 = jenis257.idjenis257');
    $this->db->join('bahasa257', 'buku257.idbahasa257 = bahasa257.idbahasa257');
    $this->db->order_by('idbuku257', 'desc');
    $query = $this->db->get();
    return $query->result();
}

}

/* End of file model_home.php */
/* Location: ./application/models/model_home.php */