<?php
defined('BASEPATH') or exit('No direct script access allowed');

class cicilan_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	//Listing
	public function listing()
	{
		$this->db->select('*');
		$this->db->from('bayar_cicilan');
		$this->db->join('pelanggan', 'bayar_cicilan.kode_pelanggan_id = pelanggan.kode_pelanggan', 'left');
		$this->db->join('motor', 'bayar_cicilan.kode_motor = motor.kode_motor', 'left');
		$this->db->join('beli_kredit', 'bayar_cicilan.kode_kredit_id = beli_kredit.kode_kredit', 'left');
		$this->db->order_by('no_bayar', 'desc');
		$query = $this->db->get();
		return $query->result();
	}

	public function cicilan_join($data)
	{
		$this->db->select('*');
		$this->db->from('bayar_cicilan');
		$this->db->join('pelanggan', 'bayar_cicilan.kode_pelanggan_id = pelanggan.kode_pelanggan', 'left');
		$this->db->join('motor', 'bayar_cicilan.kode_motor = motor.kode_motor', 'left');
		$this->db->join('beli_kredit', 'bayar_cicilan.kode_kredit_id = beli_kredit.kode_kredit', 'left');
		$this->db->where('kode_pelanggan',$data);
		$this->db->order_by('no_bayar', 'desc');
		$query = $this->db->get();
		return $query->result();
	}
	
	public function edit($data)
	{
		$this->db->where('no_bayar', $data['no_bayar']);
		$this->db->update('bayar_cicilan', $data);
	}

	//Tambah
	public function tambah($data)
	{
		$this->db->insert('bayar_cicilan', $data);
	}
	public function detaill($no_bayar)
	{
		$this->db->select('*');
		$this->db->from('bayar_cicilan');
		$this->db->where('no_bayar', $no_bayar);
		$this->db->order_by('no_bayar', 'desc');
		$query = $this->db->get();
		return $query->row();
	}

	public function pelanggan_cicil($kode_pelanggan_kredit)
	{
		$this->db->select('*');
		$this->db->from('bayar_cicilan');
		$this->db->where('kode_pelanggan_id', $kode_pelanggan_kredit);
		$query = $this->db->get();
		return $query->row();
	}
}

/* End of file cicilan_model.php */
/* Location: ./application/models/cicilan_model.php */
