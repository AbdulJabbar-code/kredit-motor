<?php
defined('BASEPATH') or exit('No direct script access allowed');

class cicilan_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	//Listing
	public function listing()
	{
		$this->db->select('*');
		$this->db->from('bayar_cicilan');
		$this->db->join('pelanggan', 'pelanggan.nama_lengkap=bayar_cicilan.pelanggan');
		$this->db->join('beli_kredit', 'bayar_cicilan.kode_kredit_id = beli_kredit.kode_kredit');
		$this->db->order_by('no_bayar', 'asc');
		$query = $this->db->get();
		return $query->result();
	}

	//Tambah
	public function tambah($data)
	{
		$this->db->insert('bayar_cicilan', $data);
	}
}

/* End of file cicilan_model.php */
/* Location: ./application/models/cicilan_model.php */
