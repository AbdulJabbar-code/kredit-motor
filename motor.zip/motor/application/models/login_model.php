<?php
class Login_model extends CI_Model {

    public function get_user_by_email($email)
    {
        // Query the database to find a user with the given email
        $query = $this->db->get_where('tb_user257', array('email' => $email));

        if ($query->num_rows() > 0) {
            // If a user with the email is found, return the user data
            return $query->row();
        } else {
            // If the email is not found, return false
            return false;
        }
    }
    
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    public function cek_login($username, $password) {
        $this->db->where("username", $username);
        $this->db->where("password", $password);

        $query = $this->db->get("tb_user257");
        return $query->row();
    }
}