<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pelanggan_model extends CI_Model {

public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	//Listing
	public function listing()
	{
		$this->db->select('*');
		$this->db->from('pelanggan');
		$this->db->order_by('kode_pelanggan','asc');
		$query = $this->db->get();
		return $query->result();
	}

	//Tambah
	public function tambah($data){
		$this->db->insert('pelanggan', $data);
	}
	public function edit($data){
		$this->db->where('kode_pelanggan',$data['kode_pelanggan']);
		$this->db->update('pelanggan', $data);
	}
	
	public function delete($where){
		$this->db->where($where);
		$this->db->delete('pelanggan');
			}
	

	public function detail($kode_pelanggan){
		$this->db->select('*');
		$this->db->from('pelanggan');
		$this->db->Where('kode_pelanggan',$kode_pelanggan);
		$this->db->order_by('kode_pelanggan','desc');
		$query = $this->db->get();
		return $query->row();
	}

}

/* End of file pelanggan_model.php */
/* Location: ./application/models/pelanggan_model.php */

