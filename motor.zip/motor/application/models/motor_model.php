<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Motor_model extends CI_Model {

public function __construct()
	{
		parent:: __construct();
		$this->load->database();
	}

	//Listing
	public function listing()
	{
		$this->db->select('*');
		$this->db->from('motor');
		$this->db->order_by('kode_motor','asc');
		$query = $this->db->get();
		return $query->result();
		
	}

	//Tambah
	public function tambah($data)
	{
		$this->db->insert('motor', $data);
	}
	public function detail($kode_motor){
		$this->db->select('*');
		$this->db->from('motor');
		$this->db->Where('kode_motor',$kode_motor);
		$this->db->order_by('kode_motor','desc');
		$query = $this->db->get();
		return $query->row();
	}
	public function edit($data){
		$this->db->where('kode_motor');
		$this->db->update('motor', $data);
	}
	public function delete($where){
$this->db->where($where);
$this->db->delete('motor');
	}

	// function untuk mencari id terakhir dari nim
     public function get_last_id() {
        $this->db->select('kode_motor');
        $this->db->from('motor');
        $this->db->order_by('kode_motor', 'DESC');
        $this->db->limit(1);
        $query  = $this->db->get();

        // auto generate code berdasarkan code terakhir. dimulai dari 
        if($query->num_rows() > 0) {
            $row = $query->row();
            return $row->kode_motor;
        } else {
            return 'RT00';
        }
    }

}

/* End of file motor_model.php */
/* Location: ./application/models/motor_model.php */