<?php
defined('BASEPATH') or exit('No direct script access allowed');

class kredit_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	//Listing
	public function listing()
	{
		$this->db->select('*');
		$this->db->from('beli_kredit');
		$this->db->join('pelanggan', 'beli_kredit.kode_pelanggan_kredit = pelanggan.kode_pelanggan', 'left');
		$this->db->join('motor', 'beli_kredit.kode_motor = motor.kode_motor', 'left');
		$this->db->order_by('kode_kredit', 'asc');
		$query = $this->db->get();
		return $query->result();
	}

	//Tambah
	public function tambah($data)
	{
		$this->db->insert('beli_kredit', $data);
	}

	public function detaill($kode_kredit)
	{
		$this->db->select('*');
		$this->db->from('beli_kredit');
		$this->db->where('kode_kredit_id', $kode_kredit);
		$this->db->order_by('kode_kredit_id', 'desc');
		$query = $this->db->get();
		return $query->row();
	}

	public function kode_kredit($kode_kredit)
	{
		$this->db->select('*');
		$this->db->from('beli_kredit');
		$this->db->where('kode_pelanggan_kredit', $kode_kredit);
		$this->db->order_by('kode_kredit_id', 'desc');
		$query = $this->db->get();
		return $query->row();
	}

	public function edit($data)
	{
		$this->db->where('kode_kredit_id', $data['kode_kredit']);
		$this->db->update('beli_kredit_id', $data);
	}
}

/* End of file kredit_model.php */
/* Location: ./application/models/kredit_model.php */
