<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merek_model extends CI_Model {
public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


	public function listing()
	{
		$this->db->select('*');
		$this->db->from('merek');
		$this->db->order_by('kode_kredit','asc');
		$query = $this->db->get();
		return $query->result();
	}

}

/* End of file merek_model.php */
/* Location: ./application/models/merek_model.php */