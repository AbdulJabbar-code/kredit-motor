<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	//Listing
	public function listing()
	{
		$this->db->select('*');
		$this->db->from('tb_user257');
		$this->db->order_by('id_user257','asc');
		$query = $this->db->get();
		return $query->result();
	}

	//Tambah
	public function tambah($data){
		$this->db->insert('tb_user257', $data);
	}

	public function detail($id_user){
		$this->db->select('*');
		$this->db->from('tb_user257');
		$this->db->Where('id_user257',$id_user);
		$this->db->order_by('id_user257','desc');
		$query = $this->db->get();
		return $query->row();
	}
	public function edit($data){
		$this->db->where('id_user257',$data['id_user257']);
		$this->db->update('tb_user257', $data);
	}
	public function delete($data){
		$this->db->where('id_user257', $data['id_user257']);
		$this->db->delete('tb_user257', $data);
	}
	public function Login($username,$password){
		$this->db->select('*');
		$this->db->from('tb_user257');
		// $this->db->where(array('username' =>$username,
		// 						'password'=>sha1($password)));
		$this->db->where(array('username' =>$username,
								'password'=>$password));
		$this->db->order_by('id_user257','desc');
		$query = $this->db->get();
		return $query->row();
}
public function getuserinfo($id_user){
	$query =$this ->db->get_where('tb_user257',array('id_user257'=>$id_user),1);
	if ($this->db->affected_rows()>0) {
		$row= $query->row();
		return $row;
		# code...
	}else{
		error_log('tidak ada user ditemukan getuserinfo('.$id_user.')');
		return false;
	}

}
public function getuserinfobyemail($email){
	$query =$this ->db->get_where('tb_user257',array('email'=>$email),1);
	if ($this->db->affected_rows()>0) {
		$row= $query->row();
		return $row;
		# code...
	}
}
//tb_token
public function inserttoken($id_token){
	$token = substr(sha1(rand()), 0,30);
	$date = date('Y-m-d');

	$string = array( 'token'=>$token,
					 'id_user'=>$id_token,
					 'created'=>$date);
	$query = $this->db->insert_string('token',$string);
	$this->db->query($query);
	return $token . $id_token;
}
public function istokenvalid($token){
	$tkn =substr($token,0,30);
	$uid =substr($token, 30);

	$query = $this->db->get_where('token', array(
		'token.token'=>$tkn,
		'token.id_user'=>$uid),1);

	if ($this->db->affected_rows()>0) {
		$row = $query->row();

		$created = $row->created;
		$createdTS = strtotime($created);
		$today = date('Y-m-d');
		$todayTS = strtotime($today);

		if ($createdTS != $todayTS) {
			# code...
			return false;
		}
		# code...
		$user_info = $this->getuserinfo($row->id_user);
		return $user_info;
	}else{
		return false;
	}
}
public function updatepassword($post){
	$this->db->where('id_user257', $post['id_user257']);
	$this->db->update('tb_user257', array('password'=>$post['password']));
		return true;
}
	function tampil()
	{
		return $this->db->get('tb_user257');
		
	}

	

}

/* End of file User.php */
/* Location: ./application/controllers/Admin/User.php */
