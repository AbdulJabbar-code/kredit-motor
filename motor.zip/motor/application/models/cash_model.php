<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class cash_model extends CI_Model {

public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	//Listing
	public function listing()
	{
		$this->db->select('*');
		$this->db->from('beli_cash');
		$this->db->join('pelanggan','beli_cash.pelanggan = pelanggan.kode_pelanggan');
		$this->db->join('motor','beli_cash.kode_motor = motor.kode_motor');
		$this->db->order_by('kode_cash','asc');
		$query = $this->db->get();
		return $query->result();
	}

	//Tambah
	public function tambah($data){
		$this->db->insert('beli_cash', $data);
	}
	

}

/* End of file cash_model.php */
/* Location: ./application/models/cash_model.php */